/* Produção de criativos do Mundo FIT com dados reais da lista 6. PRODUÇÃO DE ADS do ClickUp (642 cards da Thaix Santiago, extração de 28/10/2026).
   Editores reais: Eduardo Ribeiro, Emanuelly, Gabriel Neiva, Gabriel Miguel e Gabriel Pedrosa.
   O CSV do ClickUp não preenche Priority nem histórico de revisões; exibe ciclo real entre criação e última atualização. */
(() => {
  const byId = (id) => document.getElementById(id);
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
  const R = window.MUNDOFIT_REAL;
  const P = R.producao;
  const EDITORS = P.editores;
  const WEEKS = P.semanas;
  const STAGES = P.etapas;
  const PERIODS = {
    w: ['Esta semana, 22/10 a 28/10', 7],
    pw: ['Semana passada, 15/10 a 21/10', 7],
    m: ['Outubro até 28/10 (4 semanas)', 28]
  };
  const st = { period: 'm', editor: 'all' };
  const f1 = (v) => v.toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 });
  const int = (v) => Math.round(v).toLocaleString('pt-BR');

  function rowsForPeriod() {
    const [, days] = PERIODS[st.period];
    const list = st.editor === 'all' ? EDITORS : EDITORS.filter((e) => e.nome === st.editor);
    return list.map((e) => {
      let p = e.periodos[st.period];
      {
        const [a,b] = st.period === 'custom' ? [byId('pr-from').value,byId('pr-to').value] : PERIOD_BOUNDS[st.period];
        const between = (d) => d && d.slice(0, 10) >= a && d.slice(0, 10) <= b;
        const tasks = P.cards.filter((t) => t.editores.includes(e.nome));
        const delivered = tasks.filter((t) => between(t.atualizado) && ['pronto pra subir', 'para aprovação', 'revisão', 'ajustes'].includes(t.status));
        p = { entregues: delivered.length, criados: tasks.filter((t) => between(t.criado)).length, dias_ciclo: delivered.length ? delivered.reduce((sum, t) => sum + Math.max((new Date(t.atualizado) - new Date(t.criado)) / 86400000, 0.1), 0) / delivered.length : 0 };
      }
      const activeTotal = Math.max(e.em_edicao + e.para_aprovacao + e.em_ajustes, 1);
      return {
        name: e.nome,
        color: e.cor,
        totalCards: e.total_cards,
        prontoTotal: e.pronto_total,
        delivered: p.entregues,
        created: p.criados,
        perDay: p.entregues / days,
        daysCycle: p.dias_ciclo,
        inEdit: e.em_edicao,
        inApproval: e.para_aprovacao,
        inFix: e.em_ajustes,
        mix: [
          ['pr-mix-easy', 'Em edição: ' + e.em_edicao, (e.em_edicao / activeTotal) * 100],
          ['pr-mix-mid', 'Para aprovação: ' + e.para_aprovacao, (e.para_aprovacao / activeTotal) * 100],
          ['pr-mix-hard', 'Ajustes: ' + e.em_ajustes, (e.em_ajustes / activeTotal) * 100]
        ]
      };
    });
  }

  const PERIOD_BOUNDS = {
    w: ['2026-10-22', '2026-10-28'],
    pw: ['2026-10-15', '2026-10-21'],
    m: ['2026-10-01', '2026-10-28']
  };
  const DELIVERED_SET = ['pronto pra subir', 'para aprovação', 'revisão', 'ajustes'];

  function render() {
    const [pLabel, days] = PERIODS[st.period];
    const [fromIso, toIso] = st.period === 'custom' ? [byId('pr-from').value, byId('pr-to').value] : PERIOD_BOUNDS[st.period];
    const between = (d) => d && d.slice(0, 10) >= fromIso && d.slice(0, 10) <= toIso;
    if (st.period !== 'custom') {byId('pr-from').value=fromIso;byId('pr-to').value=toIso;}
    const rows = rowsForPeriod();
    const scopedCards = st.editor === 'all' ? P.cards : P.cards.filter((t) => t.editores.includes(st.editor));
    const deliveredCards = scopedCards.filter((t) => between(t.atualizado) && DELIVERED_SET.includes(t.status));
    const createdCards = scopedCards.filter((t) => between(t.criado));
    const totalDel = deliveredCards.length;
    const totalCreated = createdCards.length;
    const totalReady = scopedCards.filter((t) => t.status === 'pronto pra subir').length;
    const countStatus = (list) => scopedCards.filter((t) => list.includes(t.status)).length;
    const inGrav = countStatus(['gravação']);
    const inEdit = countStatus(['design / edição', 'em andamento']);
    const inApproval = countStatus(['para aprovação', 'revisão']);
    const inFix = countStatus(['ajustes']);
    const totalOpen = inGrav + inEdit + inApproval + inFix;
    const withCycle = rows.filter((r) => r.daysCycle > 0);
    const avgCycle = withCycle.length ? withCycle.reduce((a, r) => a + r.daysCycle * r.delivered, 0) / Math.max(rows.reduce((a, r) => a + r.delivered, 0), 1) : 0;

    document.querySelectorAll('.pr-period').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.period === st.period)));
    byId('pr-kpis').innerHTML = [
      ['Peças atualizadas após edição', int(totalDel) + ' peças', pLabel + ' · ' + f1(totalDel / days) + ' por dia · data da última atualização; não comprova entrega'],
      ['Criados no período', int(totalCreated) + ' cards', 'Novas peças abertas em ' + pLabel],
      ['Pronto pra subir (histórico)', int(totalReady) + ' peças', 'De ' + int(scopedCards.length) + ' cards (' + int(scopedCards.filter(t=>['links e senhas','referências'].includes(t.status)).length) + ' de apoio na lista)'],
      ['Fila ativa agora', int(totalOpen) + ' peças', (inGrav ? inGrav + ' gravação · ' : '') + inEdit + ' edição · ' + inApproval + ' aprovação · ' + inFix + ' ajustes']
    ].map(([l, v, s]) => '<div class="panel cr-kpi"><span class="cr-kpi-label">' + l + '</span><strong class="num">' + v + '</strong><small>' + s + '</small></div>').join('');

    const eds = st.editor === 'all' ? EDITORS : EDITORS.filter((e) => e.nome === st.editor);
    byId('pr-legend').innerHTML = '';
    byId('pr-weeks').innerHTML = WEEKS.map((w) => '<li class="panel vg-card"><h3>' + w.rotulo + '</h3><ul>' + eds.map((e) => '<li>' + esc(e.nome) + ': <b class="num">' + (w.entregues[e.nome] || 0) + '</b> atualizadas após edição · ' + (w.criados[e.nome] || 0) + ' criados</li>').join('') + '</ul></li>').join('');

    byId('pr-flow').innerHTML = STAGES.map((s) => '<li class="panel pr-stage ' + s.tom + '"><span class="pr-stage-name">' + esc(s.nome) + '</span><strong class="num">' + int(scopedCards.filter(t=>t.status===s.id).length) + '</strong><small>' + (s.id === 'pronto pra subir' ? 'estoque aprovado no ClickUp' : 'peças nesta etapa agora') + '</small></li>').join('');

    const bottlenecks = P.gargalos.filter((g) => st.editor === 'all' || g.editores.includes(st.editor)).slice(0, 6);
    byId('pr-alert').hidden = bottlenecks.length === 0;
    byId('pr-alert-title').textContent = 'Cards abertos há mais dias na fila (' + bottlenecks.length + ' em destaque)';
    byId('pr-alerts').innerHTML = bottlenecks.map((g) => '<li><b>' + esc(g.nome) + '</b> (' + esc(g.id) + ') está em <b>' + esc(g.status) + '</b> há <b class="num">' + g.dias_aberto + ' dias</b> (criado em ' + g.criado_em + ', atualizado em ' + g.atualizado_em + ') · ' + esc(g.editores.join(', ') || 'Sem editor') + '.</li>').join('');

    byId('pr-body').innerHTML = [...rows].sort((a, b) => b.delivered - a.delivered || b.prontoTotal - a.prontoTotal).map((r) => {
      const slow = avgCycle > 0 && r.daysCycle > avgCycle * 1.25 && r.delivered > 0;
      const openNow = r.inEdit + r.inApproval + r.inFix;
      return '<tr' + (slow ? ' class="cr-row-warn"' : '') + '><th scope="row"><span class="pr-ed"><i class="vg-k ' + r.color + '"></i>' + esc(r.name) + '</span></th>' +
        '<td class="right num"><b>' + int(r.delivered) + '</b> <small class="muted">(' + int(r.created) + ' criados)</small></td>' +
        '<td class="right num">' + f1(r.perDay) + '</td>' +
        '<td class="right num">' + int(r.prontoTotal) + ' <small class="muted">de ' + int(r.totalCards) + '</small></td>' +
        '<td class="right num">' + int(r.inApproval) + '</td>' +
        '<td class="right num ' + (r.inFix > 0 ? 'neg' : '') + '">' + int(r.inFix) + '</td>' +
        '<td class="right num ' + (slow ? 'neg' : '') + '">' + (r.delivered ? f1(r.daysCycle) + ' d' : 'Sem movimento') + '</td>' +
        '<td class="right num">' + int(r.inEdit) + '</td>' +
        '<td>' + (openNow ? '<div class="pr-mix" role="img" aria-label="Fila ativa: ' + r.inEdit + ' em edição, ' + r.inApproval + ' para aprovação e ' + r.inFix + ' em ajustes">' +
          r.mix.map(([cls, label, w]) => '<i class="' + cls + '" style="width:' + w.toFixed(1) + '%" title="' + label + '"></i>').join('') + '</div>' : '<span class="muted">Fila zerada</span>') + '</td></tr>';
    }).join('');
  }

  byId('pr-editor').innerHTML = '<option value="all">Todos os editores (' + EDITORS.length + ')</option>' + EDITORS.map((e) => '<option value="' + esc(e.nome) + '">' + esc(e.nome) + '</option>').join('');
  byId('pr-editor').addEventListener('change', (e) => { st.editor = e.target.value; render(); });
  document.querySelectorAll('.pr-period').forEach((b) => b.addEventListener('click', () => { st.period = b.dataset.period; render(); }));
  byId('pr-custom').addEventListener('click', () => {
    const a = byId('pr-from'), b = byId('pr-to');
    a.setCustomValidity(''); b.setCustomValidity('');
    if (!a.value || !b.value || a.value > b.value || b.value > '2026-10-28') { b.setCustomValidity('Escolha início e fim válidos até 28/10/2026.'); b.reportValidity(); return; }
    PERIODS.custom = ['Período personalizado: ' + a.value + ' a ' + b.value, Math.round((new Date(b.value) - new Date(a.value)) / 86400000) + 1];
    st.period = 'custom'; render();
  });
  render();
})();
