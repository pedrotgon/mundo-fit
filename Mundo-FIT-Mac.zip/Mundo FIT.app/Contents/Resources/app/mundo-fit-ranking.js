/* Ranking do Mundo FIT com dados reais: anúncios da Utmify em 7 dias (22/10 a 28/10) cruzados com os cards do ClickUp.
   Autoria: só cards com nome exato da variação. Tiago Neiva (TN) é o único copywriter. Os outros responsáveis do card são editores.
   Ordem por lucro, até Pedro Ivo Torres definir a regra de pontos. Ícones: Fluent 2 Regular. */
(() => {
  const ICONS = {"Edit24Regular": ["M20.95 3.05a3.6 3.6 0 0 0-5.06 0L3.94 15c-.4.4-.7.92-.82 1.48l-1.1 4.6a.75.75 0 0 0 .9.9l4.6-1.1A3 3 0 0 0 9 20.07L20.95 8.11a3.6 3.6 0 0 0 0-5.06m-4 1.06a2.08 2.08 0 1 1 2.94 2.94l-.89.89L16.06 5zM15 6.06 17.94 9l-10 10a1.6 1.6 0 0 1-.76.43l-3.42.8.82-3.4q.1-.45.42-.77z"], "VideoClip24Regular": ["M2 6.25C2 4.45 3.46 3 5.25 3h13.5C20.55 3 22 4.46 22 6.25v11.5c0 1.8-1.46 3.25-3.25 3.25H5.25A3.25 3.25 0 0 1 2 17.75zM5.25 4.5c-.97 0-1.75.78-1.75 1.75v11.5c0 .97.78 1.75 1.75 1.75h13.5c.97 0 1.75-.78 1.75-1.75V6.25c0-.97-.78-1.75-1.75-1.75zM9 9.25v5.5a1 1 0 0 0 1.48.88l5-2.75a1 1 0 0 0 0-1.76l-5-2.75A1 1 0 0 0 9 9.25"], "Filmstrip24Regular": ["M2 7.25C2 5.45 3.46 4 5.25 4h13.5C20.55 4 22 5.46 22 7.25v9.5c0 1.8-1.46 3.25-3.25 3.25H5.25A3.25 3.25 0 0 1 2 16.75zM5.25 5.5c-.97 0-1.75.78-1.75 1.75v9.5c0 .97.78 1.75 1.75 1.75h13.5c.97 0 1.75-.78 1.75-1.75v-9.5c0-.97-.78-1.75-1.75-1.75zM17.5 7.75a.75.75 0 0 1 1.5 0v.5a.75.75 0 0 1-1.5 0zm.75 7.25a.75.75 0 0 0-.75.75v.5a.75.75 0 0 0 1.5 0v-.5a.75.75 0 0 0-.75-.75m-.75-3.25a.75.75 0 0 1 1.5 0v.5a.75.75 0 0 1-1.5 0zM5.75 7a.75.75 0 0 0-.75.75v.5a.75.75 0 0 0 1.5 0v-.5A.75.75 0 0 0 5.75 7M5 15.75a.75.75 0 0 1 1.5 0v.5a.75.75 0 0 1-1.5 0zM5.75 11a.75.75 0 0 0-.75.75v.5a.75.75 0 0 0 1.5 0v-.5a.75.75 0 0 0-.75-.75"], "Megaphone24Regular": ["M21.9 5.62q.1.32.1.64v11.48a2.25 2.25 0 0 1-2.9 2.16l-5.5-1.64A4 4 0 0 1 6 16.7V16l-2.4-.71A2.25 2.25 0 0 1 2 13.13v-2.26c0-1 .65-1.87 1.6-2.16l15.5-4.6c1.2-.36 2.45.32 2.8 1.51M7.5 16.44v.06a2.5 2.5 0 0 0 4.62 1.32zm12.04-10.9-15.5 4.61a.75.75 0 0 0-.54.72v2.26c0 .33.22.63.54.72l15.5 4.6a.75.75 0 0 0 .96-.71V6.26a.75.75 0 0 0-.96-.72"], "Trophy24Regular": ["M15.25 2c1.16 0 2.12.88 2.24 2h1.27c.92 0 1.67.7 1.74 1.6v3.15a3.25 3.25 0 0 1-3.06 3.24l-.2.01a5.8 5.8 0 0 1-4.74 3.95v1.55h1.75a3.25 3.25 0 0 1 3.25 3.07v.68c0 .38-.28.7-.64.74l-.1.01h-10a.75.75 0 0 1-.75-.65v-.6a3.25 3.25 0 0 1 3.06-3.24l.18-.01H11v-1.55A5.8 5.8 0 0 1 6.27 12h-.02A3.25 3.25 0 0 1 3 8.75v-3C3 4.78 3.78 4 4.75 4H6c.13-1.12 1.08-2 2.24-2zm-1 17h-5c-.83 0-1.52.58-1.7 1.35l-.03.15h8.47A1.75 1.75 0 0 0 14.4 19zm1-15.5h-7a.75.75 0 0 0-.75.75v6a4.25 4.25 0 0 0 8.5 0v-6a.75.75 0 0 0-.75-.75m3.5 2H17.5v4.98c.8-.11 1.43-.76 1.5-1.58V5.75a.3.3 0 0 0-.18-.24zM6 5.5H4.75a.25.25 0 0 0-.25.25v3c0 .88.65 1.61 1.5 1.73z"], "Warning16Regular": ["M5.82 2.28a2.5 2.5 0 0 1 4.36 0l4.5 8A2.5 2.5 0 0 1 12.5 14h-9a2.5 2.5 0 0 1-2.18-3.72zm3.49.48a1.5 1.5 0 0 0-2.62 0l-4.5 8a1.5 1.5 0 0 0 1.31 2.24h9a1.5 1.5 0 0 0 1.3-2.23zM8 9.5A.75.75 0 1 1 8 11a.75.75 0 0 1 0-1.5M8 5c.28 0 .5.22.5.5V8a.5.5 0 0 1-1 0V5.5c0-.28.22-.5.5-.5"], "ArrowTrending16Regular": ["M8.5 4h5.04l.09.02.06.02.06.03.06.04.06.05.04.05.04.06.03.08.01.04.01.09V9.5a.5.5 0 0 1-.99.09V5.7l-5.15 5.15a.5.5 0 0 1-.64.06l-.07-.06L5.5 9.21l-2.65 2.64a.5.5 0 0 1-.76-.63l.06-.07 3-3a.5.5 0 0 1 .63-.06l.07.06L7.5 9.79 12.3 5H8.5a.5.5 0 0 1-.5-.41V4.5c0-.28.22-.5.5-.5"], "ArrowTrendingDown16Regular": ["M8.5 12h5.04l.09-.02.06-.02.06-.03.06-.04.06-.05.04-.05.04-.06.03-.08.01-.04.01-.09V6.5a.5.5 0 0 0-.99-.09v3.89L7.85 5.14a.5.5 0 0 0-.64-.06l-.07.06L5.5 6.79 2.85 4.15a.5.5 0 0 0-.76.63l.06.07 3 3c.17.18.44.2.63.06l.07-.06L7.5 6.21 12.3 11H8.5a.5.5 0 0 0-.5.41v.09c0 .28.22.5.5.5"], "Subtract16Regular": ["M3 8c0-.28.22-.5.5-.5h9a.5.5 0 0 1 0 1h-9A.5.5 0 0 1 3 8"], "CheckmarkCircle16Regular": ["M2 8a6 6 0 1 1 12 0A6 6 0 0 1 2 8m6-7a7 7 0 1 0 0 14A7 7 0 0 0 8 1m2.85 5.85a.5.5 0 0 0-.7-.7l-2.9 2.9-1.4-1.4a.5.5 0 1 0-.7.7L6.9 10.1c.2.2.5.2.7 0z"]};
  const icon = (n) => '<svg viewBox="0 0 ' + (n.endsWith('16Regular') ? '16 16' : '24 24') + '" aria-hidden="true">' + ICONS[n].map((d) => '<path d="' + d + '"/>').join('') + '</svg>';
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
  const byId = (id) => document.getElementById(id);
  const R = window.MUNDOFIT_REAL;
  const st = { area: 'all', period: 'sete_dias' };
  const brl = (v) => 'BRL ' + v.toLocaleString('pt-BR', {minimumFractionDigits: 2, maximumFractionDigits: 2});
  const int = (v) => v.toLocaleString('pt-BR');
  const roles = [['copy','Copywriter','Edit24Regular'],['ads','Editores ADS','VideoClip24Regular'],['vsl','Editores VSL','Filmstrip24Regular'],['traffic','Gestores de tráfego','Megaphone24Regular']];
  const editors = [...new Set(R.producao.editores.map(e => e.nome))].sort();
  function panel(key, title, ic, total, rows) {
    const names = key === 'copy' ? ['Tiago Neiva'] : key === 'ads' ? editors : [];
    const cards = names.map(name => {
      const ads = rows.filter(a => (key === 'copy' ? a.copy : a.editor) === name);
      const sum = k => ads.reduce((n,a) => n + a[k],0);
      const credit = key === 'copy' && total;
      return '<li class="rf-card"><div class="rf-credit-head"><b>' + esc(name) + '</b><span class="rf-pts"><strong>' + (credit ? brl(total.lucro) : 'A conciliar') + '</strong><small>' + (credit ? 'Crédito de autoria da operação' : 'Retorno financeiro total') + '</small></span></div>' +
      (credit ? '<dl class="rf-metrics"><div><dt>Faturamento líquido da operação</dt><dd>' + brl(total.liquido) + '</dd></div><div><dt>Gastos da operação</dt><dd>' + brl(total.gastos) + '</dd></div></dl><p>100% de crédito de copy, conforme autoria exclusiva informada pela equipe. Não é comissão nem atribuição causal de todas as vendas.</p>' : '<p>O total financeiro por anúncio não está conciliado neste período. Ausência de dados não significa resultado zero.</p>') +
      (ads.length ? '<details><summary>Conferir recorte rastreado: ' + int(ads.length) + ' linhas</summary><dl class="rf-metrics"><div><dt>Receita rastreada</dt><dd>' + brl(sum('faturamento')) + '</dd></div><div><dt>Gastos rastreados</dt><dd>' + brl(sum('gastos')) + '</dd></div><div><dt>Saldo parcial</dt><dd>' + brl(sum('lucro')) + '</dd></div><div><dt>Vendas rastreadas</dt><dd>' + int(sum('vendas')) + '</dd></div></dl><p>Este recorte não representa o lucro total da pessoa. Os valores originais foram preservados.</p></details>' : '') + '</li>';
    }).join('');
    return '<section class="panel rf-panel"><header class="rf-head"><span class="vg-ic">' + icon(ic) + '</span><h2>' + title + '</h2><span class="rf-count">' + (names.length ? names.length + ' cadastrado(s)' : 'Vínculos pendentes') + '</span></header>' + (cards ? '<ul class="rf-cards">' + cards + '</ul>' : '<p class="vg-empty-role">Responsáveis ainda não vinculados nesta função.</p>') + '</section>';
  }
  function render() {
    const week = R.semanas.find(w => w.id === st.period);
    let total = R.periodos[st.period] || null;
    if(week) {const days=(R.historico||[]).filter(d=>d.iso>=week.inicio && d.iso<=week.fim);if(days.length===7) total=Object.fromEntries(['liquido','gastos','lucro'].map(k=>[k,days.reduce((n,d)=>n+d[k],0)]));}
    const custom = st.period === 'custom';
    byId('rf-from').disabled = !custom; byId('rf-to').disabled = !custom;
    const bounds = week ? [week.inicio,week.fim] : {sete_dias:['2026-10-22','2026-10-28'],outubro:['2026-10-01','2026-10-28'],setembro:['2026-09-01','2026-09-30']}[st.period];
    if(bounds) {byId('rf-from').value=bounds[0];byId('rf-to').value=bounds[1];}
    if(custom) {
      const a=byId('rf-from').value,b=byId('rf-to').value;
      if(!a || !b || a>b) {byId('rf-coverage').textContent='Selecione um intervalo válido.';byId('rf-grid').innerHTML='';return;}
      const exact = Object.entries({sete_dias:['2026-10-22','2026-10-28'],outubro:['2026-10-01','2026-10-28'],setembro:['2026-09-01','2026-09-30']}).find(([,v]) => v[0]===a && v[1]===b);
      if(exact) total=R.periodos[exact[0]];
      else {
        const days=(R.historico||R.diario).filter(d => {const iso=d.iso||('2026-'+d.data.slice(3)+'-'+d.data.slice(0,2));return iso>=a && iso<=b;});
        const count=Math.round((new Date(b)-new Date(a))/86400000)+1;
        if(days.length===count) total=Object.fromEntries(['liquido','gastos','lucro'].map(k=>[k,days.reduce((n,d)=>n+d[k],0)]));
      }
    }
    const rows = week ? week.criativos : st.period==='sete_dias' ? R.criativos : [];
    byId('rf-coverage').textContent = (total ? 'Lucro da operação: '+brl(total.lucro)+'. ' : 'Total da operação ainda não conciliado neste intervalo. ') + 'Tiago permanece como autor das copies em todos os períodos. Editores permanecem cadastrados. A classificação financeira fica pendente até conciliar as receitas por anúncio. Créditos de copy e edição não devem ser somados.' + (week ? ' Fonte do recorte: ABO/CBO, '+week.rotulo+'. A planilha semanal não substitui o total da operação.' : '');
    byId('rf-grid').innerHTML=roles.filter(r=>st.area==='all'||r[0]===st.area).map(r=>panel(...r,total,rows)).join('');
  }
  byId('rf-area').innerHTML='<option value="all">Todas as áreas</option>'+roles.map(r=>'<option value="'+r[0]+'">'+r[1]+'</option>').join('');
  byId('rf-period').insertAdjacentHTML('beforeend',R.semanas.map(w=>'<option value="'+w.id+'">Semana '+w.rotulo+'</option>').join(''));
  byId('rf-from').min='2026-09-01';byId('rf-to').min='2026-09-01';
  byId('rf-area').addEventListener('change',e=>{st.area=e.target.value;render();});
  ['rf-period','rf-from','rf-to'].forEach(id=>byId(id).addEventListener('change',()=>{st.period=byId('rf-period').value;render();}));
  render();
})();
