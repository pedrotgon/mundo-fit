/* Conquistas do Mundo FIT calculadas a partir dos dados reais da Utmify e do ClickUp (extração de 28/10/2026 19:05).
   Raridades do Fahto Champions: comum, rara, épica e lendária. Ícones: Fluent 2 Regular. */
(() => {
  const ICONS = {
    LockClosed16Regular: ['M8 1a4 4 0 0 1 4 4v2h.25C13.22 7 14 7.78 14 8.75v4.5c0 .97-.78 1.75-1.75 1.75h-8.5C2.78 15 2 14.22 2 13.25v-4.5C2 7.78 2.78 7 3.75 7H4V5a4 4 0 0 1 4-4m0 1a3 3 0 0 0-3 3v2h6V5a3 3 0 0 0-3-3m4.25 6h-8.5a.75.75 0 0 0-.75.75v4.5c0 .41.34.75.75.75h8.5c.41 0 .75-.34.75-.75v-4.5a.75.75 0 0 0-.75-.75M8 10a1 1 0 1 1 0 2 1 1 0 0 1 0-2'],
    Cart24Regular: ['M2.5 4.25c0-.41.34-.75.75-.75h.56c.95 0 1.52.64 1.84 1.23.22.4.38.86.5 1.27h12.6c.83 0 1.43.8 1.2 1.6L18.12 14a2.75 2.75 0 0 1-2.64 2H9.53a2.75 2.75 0 0 1-2.65-2.02l-.76-2.78-1.26-4.24v-.01c-.16-.57-.3-1.1-.52-1.5C4.13 5.07 3.96 5 3.8 5h-.56a.75.75 0 0 1-.75-.75m5.07 6.59.75 2.74c.15.54.65.92 1.21.92h5.95c.56 0 1.05-.37 1.2-.9l1.74-6.1H6.59l.97 3.29zM11 19a2 2 0 1 1-4 0 2 2 0 0 1 4 0m-1.5 0a.5.5 0 1 0-1 0 .5.5 0 0 0 1 0m8.5 0a2 2 0 1 1-4 0 2 2 0 0 1 4 0m-1.5 0a.5.5 0 1 0-1 0 .5.5 0 0 0 1 0'],
    Sparkle24Regular: ['M8.67 15.73q.37.27.83.27a1.4 1.4 0 0 0 1.33-.88l.61-1.86a2.9 2.9 0 0 1 1.82-1.81l1.78-.58a1.44 1.44 0 0 0-.06-2.74l-1.75-.57a2.9 2.9 0 0 1-1.82-1.82l-.58-1.78a1.45 1.45 0 0 0-2.73.02l-.59 1.8a2.9 2.9 0 0 1-1.77 1.78l-1.77.57a1.44 1.44 0 0 0 .01 2.73l1.76.57a2.9 2.9 0 0 1 1.82 1.83l.58 1.77q.15.44.53.7m-.38-4.25-.36-.4A4.4 4.4 0 0 0 6.21 10l-1.6-.5 1.61-.53A4.4 4.4 0 0 0 8.95 6.2l.52-1.58.51 1.59a4.4 4.4 0 0 0 2.79 2.77l1.61.52-1.58.52a4.4 4.4 0 0 0-2.78 2.77l-.51 1.59-.52-1.59q-.25-.71-.7-1.3m8.04 9.3q-.29-.2-.4-.55l-.34-1a1.3 1.3 0 0 0-.82-.83l-.99-.32A1.15 1.15 0 0 1 13 17a1.1 1.1 0 0 1 .77-1.08l1-.33a1.3 1.3 0 0 0 .8-.82l.33-.99a1.14 1.14 0 0 1 2.16-.02l.33 1.01a1.3 1.3 0 0 0 .82.82l.99.32a1.14 1.14 0 0 1 .04 2.17l-1.01.33a1.3 1.3 0 0 0-.82.82l-.32.99a1.14 1.14 0 0 1-1.76.56M15.3 17a2.8 2.8 0 0 1 1.7 1.7 2.8 2.8 0 0 1 1.7-1.7 2.8 2.8 0 0 1-1.72-1.7A2.8 2.8 0 0 1 15.3 17'],
    Trophy24Regular: ['M15.25 2c1.16 0 2.12.88 2.24 2h1.27c.92 0 1.67.7 1.74 1.6v3.15a3.25 3.25 0 0 1-3.06 3.24l-.2.01a5.8 5.8 0 0 1-4.74 3.95v1.55h1.75a3.25 3.25 0 0 1 3.25 3.07v.68c0 .38-.28.7-.64.74l-.1.01h-10a.75.75 0 0 1-.75-.65v-.6a3.25 3.25 0 0 1 3.06-3.24l.18-.01H11v-1.55A5.8 5.8 0 0 1 6.27 12h-.02A3.25 3.25 0 0 1 3 8.75v-3C3 4.78 3.78 4 4.75 4H6c.13-1.12 1.08-2 2.24-2zm-1 17h-5c-.83 0-1.52.58-1.7 1.35l-.03.15h8.47A1.75 1.75 0 0 0 14.4 19zm1-15.5h-7a.75.75 0 0 0-.75.75v6a4.25 4.25 0 0 0 8.5 0v-6a.75.75 0 0 0-.75-.75m3.5 2H17.5v4.98c.8-.11 1.43-.76 1.5-1.58V5.75a.3.3 0 0 0-.18-.24zM6 5.5H4.75a.25.25 0 0 0-.25.25v3c0 .88.65 1.61 1.5 1.73z'],
    CheckmarkStarburst24Regular: ['M6.35 3.75a2.75 2.75 0 0 1 3.81-1.58l1.29.63c.35.17.75.17 1.1 0l1.28-.63a2.75 2.75 0 0 1 3.69 1.25l.07.16.06.17.46 1.36c.13.36.42.65.78.78l1.36.46a2.75 2.75 0 0 1 1.58 3.82l-.63 1.28c-.17.35-.17.75 0 1.1l.63 1.29a2.75 2.75 0 0 1-1.58 3.81l-1.36.46c-.36.13-.65.42-.78.78l-.46 1.36a2.75 2.75 0 0 1-3.82 1.58l-1.28-.63a1.3 1.3 0 0 0-1.1 0l-1.28.63a2.75 2.75 0 0 1-3.82-1.58l-.46-1.36a1.3 1.3 0 0 0-.78-.78l-1.36-.46a2.75 2.75 0 0 1-1.58-3.81l.63-1.29c.17-.35.17-.75 0-1.1l-.63-1.28a2.75 2.75 0 0 1 1.58-3.82l1.36-.46c.36-.13.65-.42.78-.78zm9.76.22a1.25 1.25 0 0 0-1.61-.45l-1.29.63c-.76.37-1.66.37-2.42 0L9.5 3.52a1.26 1.26 0 0 0-1.73.72L7.3 5.59c-.28.8-.91 1.44-1.72 1.72l-1.35.46q-.08.02-.16.06c-.61.3-.87 1.05-.56 1.67l.63 1.29c.37.76.37 1.66 0 2.42l-.63 1.29a1.25 1.25 0 0 0 .72 1.73l1.35.46c.8.28 1.44.91 1.72 1.72l.46 1.35q.02.08.06.15c.3.62 1.05.88 1.67.57l1.29-.63a2.8 2.8 0 0 1 2.42 0l1.29.63.15.07c.65.22 1.36-.13 1.58-.79l.46-1.35c.28-.8.91-1.44 1.72-1.72l1.35-.46q.08-.02.15-.06c.62-.3.88-1.05.57-1.67l-.63-1.29a2.8 2.8 0 0 1 0-2.42l.63-1.29.07-.15a1.25 1.25 0 0 0-.79-1.58l-1.35-.46a2.8 2.8 0 0 1-1.72-1.72l-.46-1.35-.03-.08-.03-.08zm-.89 5a.75.75 0 1 1 1.06 1.06l-5 5c-.3.3-.77.3-1.06 0l-2.5-2.5a.75.75 0 0 1 1.06-1.06l1.97 1.97z'],
    ArrowTrending24Regular: ['M13.75 5.5h7.55l.1.01.1.03.06.03q.13.04.22.15l.04.04.04.06.06.09.04.09.02.06.01.07.01.1v7.52a.75.75 0 0 1-1.5.1v-5.8l-7.72 7.73a.75.75 0 0 1-.98.07l-.08-.07-2.97-2.97-5.47 5.47a.75.75 0 0 1-1.13-.98l.07-.08 6-6a.75.75 0 0 1 .98-.07l.08.07 2.97 2.97L19.44 7h-5.7a.75.75 0 0 1-.73-.65l-.01-.1c0-.38.28-.7.65-.74z'],
    Target24Regular: ['M12 14a2 2 0 1 0 0-4 2 2 0 0 0 0 4m-6-2a6 6 0 1 1 12 0 6 6 0 0 1-12 0m6-4.5a4.5 4.5 0 1 0 0 9 4.5 4.5 0 0 0 0-9M2 12a10 10 0 1 1 20 0 10 10 0 0 1-20 0m10-8.5a8.5 8.5 0 1 0 0 17 8.5 8.5 0 0 0 0-17'],
    Wallet24Regular: ['M15.5 13.75c0-.41.34-.75.75-.75h2a.75.75 0 0 1 0 1.5h-2a.75.75 0 0 1-.75-.75M3 5h.01c.13-1.12 1.08-2 2.24-2h11.5C17.99 3 19 4 19 5.25v.84a3.25 3.25 0 0 1 2.5 3.16v8.5c0 1.8-1.46 3.25-3.25 3.25h-12A3.25 3.25 0 0 1 3 17.75zm15.25 2.5H4.5v10.25c0 .97.78 1.75 1.75 1.75h12c.97 0 1.75-.78 1.75-1.75v-8.5c0-.97-.78-1.75-1.75-1.75M17.5 6v-.75a.75.75 0 0 0-.75-.75H5.25a.75.75 0 0 0 0 1.5z'],
    VideoClip24Regular: ['M2 6.25C2 4.45 3.46 3 5.25 3h13.5C20.55 3 22 4.46 22 6.25v11.5c0 1.8-1.46 3.25-3.25 3.25H5.25A3.25 3.25 0 0 1 2 17.75zM5.25 4.5c-.97 0-1.75.78-1.75 1.75v11.5c0 .97.78 1.75 1.75 1.75h13.5c.97 0 1.75-.78 1.75-1.75V6.25c0-.97-.78-1.75-1.75-1.75zM9 9.25v5.5a1 1 0 0 0 1.48.88l5-2.75a1 1 0 0 0 0-1.76l-5-2.75A1 1 0 0 0 9 9.25']
  };
  const icon = (n) => '<svg viewBox="0 0 ' + (n.endsWith('16Regular') ? '16 16' : '24 24') + '" aria-hidden="true">' + ICONS[n].map((d) => '<path d="' + d + '"/>').join('') + '</svg>';
  const byId = (id) => document.getElementById(id);
  const int = (v) => Math.round(v).toLocaleString('pt-BR');
  const brl = (v) => 'BRL ' + Math.round(v).toLocaleString('pt-BR');

  const R = window.MUNDOFIT_REAL;
  const O = R.periodos.outubro;
  const S = R.periodos.setembro;
  const P7 = R.periodos.sete_dias;
  const bestDay = [...(R.historico || R.diario).filter(d=>d.data.endsWith('/10'))].sort((a, b) => b.vendas - a.vendas)[0];
  const topSalesAd = [...R.criativos].sort((a, b) => b.vendas - a.vendas)[0];
  const topProfitAd = [...R.criativos].sort((a, b) => b.lucro - a.lucro)[0];
  const validAds = R.semanas.at(-1).validados.length;
  const readyCards = (R.producao.etapas.find((e) => e.id === 'pronto pra subir') || { pecas: 580 }).pecas;
  const naSource = (P7.fontes.find((f) => f.fonte === 'N/A') || { share_pct: 13.3 }).share_pct;

  const RARITY = { common: 'Comum', rare: 'Rara', epic: 'Épica', legendary: 'Lendária' };
  const ITEMS = [
    ['Placa Big Player BRL 1M', 'Acumulado na Utmify em BRL 2,7M (270% da placa de BRL 1M)', 'Trophy24Regular', 'legendary', 'Utmify · 28/10/2026'],
    ['20.000 vendas no Q4', int(O.vendas) + ' vendas aprovadas em outubro até 28/10', 'Cart24Regular', 'legendary', O.vendas >= 20000 ? 'Outubro/2026' : ''],
    ['10.000 vendas no Q4', int(O.vendas) + ' vendas aprovadas acumuladas no trimestre', 'Cart24Regular', 'epic', O.vendas >= 10000 ? 'Outubro/2026' : ''],
    ['5.000 vendas no Q4', 'Marco intermediário de escala atingido em outubro', 'Cart24Regular', 'rare', O.vendas >= 5000 ? 'Outubro/2026' : ''],
    ['1.000 vendas no Q4', 'Primeiras mil vendas aprovadas do trimestre', 'Cart24Regular', 'common', O.vendas >= 1000 ? 'Outubro/2026' : ''],
    ['BRL 100 mil de lucro no Q4', brl(O.lucro) + ' de lucro líquido acumulado em outubro (ROAS ' + O.roas.toLocaleString('pt-BR', { minimumFractionDigits: 2 }) + 'x)', 'Wallet24Regular', 'epic', O.lucro >= 100000 ? 'Outubro/2026' : ''],
    ['Dia acima de 900 vendas', int(bestDay.vendas) + ' vendas aprovadas e ' + brl(bestDay.liquido) + ' líquidos em ' + bestDay.data, 'ArrowTrending24Regular', 'rare', bestDay.vendas >= 900 ? bestDay.data + '/2026' : ''],
    ['Criativo acima de 300 vendas (7d)', topSalesAd.nome + ' somou ' + int(topSalesAd.vendas) + ' vendas e ' + brl(topSalesAd.faturamento) + ' em 7 dias', 'Sparkle24Regular', 'epic', topSalesAd.vendas >= 300 ? '28/10/2026' : ''],
    ['Criativo acima de BRL 1 mil de lucro (7d)', topProfitAd.nome + ' gerou BRL ' + topProfitAd.lucro.toLocaleString('pt-BR', { minimumFractionDigits: 2 }) + ' de lucro (ROAS ' + topProfitAd.roas.toLocaleString('pt-BR', { minimumFractionDigits: 2 }) + 'x)', 'CheckmarkStarburst24Regular', 'rare', topProfitAd.lucro >= 1000 ? '28/10/2026' : ''],
    ['500 peças prontas pra subir', int(readyCards) + ' cards aprovados no estoque da lista 6. PRODUÇÃO DE ADS', 'VideoClip24Regular', 'rare', readyCards >= 500 ? '28/10/2026' : ''],
    ['20 ADs validados na mesma semana', validAds + ' de 20 criativos com status Validado na planilha de 19/10 a 25/10', 'CheckmarkStarburst24Regular', 'epic', validAds >= 20 ? '28/10/2026' : ''],
    ['Superar setembro em faturamento líquido', brl(O.liquido) + ' de ' + brl(S.liquido) + ' líquidos (' + ((O.liquido / S.liquido) * 100).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + '% no dia 28/31)', 'Target24Regular', 'legendary', O.liquido >= S.liquido ? 'Outubro/2026' : ''],
    ['Rastreamento UTM acima de 95%', (100 - naSource).toLocaleString('pt-BR', { minimumFractionDigits: 1 }) + '% das vendas de 7 dias têm origem identificada (' + naSource.toLocaleString('pt-BR', { minimumFractionDigits: 1 }) + '% sem UTM)', 'Target24Regular', 'epic', 100 - naSource >= 95 ? '28/10/2026' : '']
  ];

  const unlocked = ITEMS.filter((i) => i[4]).length;
  const pct = Math.round((unlocked / ITEMS.length) * 100);
  byId('cq-summary').innerHTML = '<b>' + unlocked + ' de ' + ITEMS.length + '</b> conquistas reais desbloqueadas (' + pct + '%)';
  byId('cq-bar').style.width = pct + '%';
  byId('cq-bar').parentElement.setAttribute('aria-label', unlocked + ' de ' + ITEMS.length + ' conquistas desbloqueadas');
  byId('cq-grid').innerHTML = ITEMS.map(([title, desc, ic, r, date]) =>
    '<li class="panel cq-card ' + r + (date ? ' on' : ' locked') + '">' +
    '<div class="cq-head"><span class="cq-ic">' + icon(ic) + '</span><span class="cq-tag">' + (date ? RARITY[r] : icon('LockClosed16Regular') + RARITY[r]) + '</span></div>' +
    '<h2>' + title + '</h2><p>' + desc + '</p>' +
    '<footer class="cq-foot">' + (date ? 'Desbloqueada · <time>' + date + '</time>' : 'Em andamento · meta real da operação') + '</footer></li>'
  ).join('');
})();
