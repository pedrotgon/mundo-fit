#!/usr/bin/env python3
"""Servidor HTTP e API REST PostgreSQL + ADK do sistema Mundo FIT para execucao em Docker."""
from __future__ import annotations

import json
import os
import sys
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, unquote

PUBLIC_DIR = Path(os.environ.get('MUNDOFIT_PUBLIC_DIR', '/app/public')).resolve()
sys.path.insert(0, str(PUBLIC_DIR))

try:
    import psycopg
    from psycopg.rows import dict_row
except ImportError:
    psycopg = None  # type: ignore[assignment]
    dict_row = None  # type: ignore[assignment]


def db_conn():
    if psycopg is None:
        raise RuntimeError('Driver psycopg nao instalado.')
    dsn = os.environ.get(
        'DATABASE_URL',
        'postgresql://mundofit:mundofit_nomad_2026@db:5432/mundofit',
    )
    return psycopg.connect(dsn, row_factory=dict_row)


def consultar_postgres_resumo() -> dict:
    with db_conn() as conn, conn.cursor() as cur:
        cur.execute('SELECT * FROM utmify_periodos ORDER BY periodo_id;')
        periodos = cur.fetchall()
        cur.execute('SELECT * FROM utmify_diario ORDER BY data_curta;')
        diario = cur.fetchall()
        cur.execute('SELECT * FROM utmify_contas_meta ORDER BY gastos_7d_brl DESC;')
        contas = cur.fetchall()
        cur.execute('SELECT COUNT(*) AS total, COUNT(editor) AS com_editor FROM criativos_7d;')
        criativos_cnt = cur.fetchone()
        cur.execute('SELECT * FROM clickup_producao_etapas ORDER BY ordem;')
        etapas = cur.fetchall()
        cur.execute('SELECT * FROM clickup_editores_resumo ORDER BY entregues_outubro DESC;')
        editores = cur.fetchall()
        cur.execute('SELECT * FROM semanas_planilhas ORDER BY inicio;')
        semanas = cur.fetchall()
        cur.execute('SELECT COUNT(*) AS n FROM clickup_cards;')
        cards_cnt = cur.fetchone()
        cur.execute('SELECT COUNT(*) AS n FROM utmify_campanhas_hoje;')
        camp_cnt = cur.fetchone()
    runtime = gerar_dados_reais_js_do_postgres()
    financial = json.loads(runtime.split('window.MUNDOFIT_REAL = ', 1)[1].rstrip(';\n'))
    for row in periodos:
        period = financial['periodos'][row['periodo_id']]
        for col, key in {'vendas_aprovadas':'vendas', 'faturamento_liquido_brl':'liquido', 'gastos_anuncios_brl':'gastos', 'lucro_liquido_brl':'lucro', 'cpa_brl':'cpa', 'margem_pct':'margem'}.items():
            row[col] = period[key]
        row['financeiro_extraido_em'] = financial['financeiro_extraido_em']
    return {
        'status': 'ok',
        'engine': 'PostgreSQL 16',
        'periodos': periodos,
        'diario_7d': financial['diario'],
        'historico_financeiro_dias': len(financial['historico']),
        'contas_meta_7d': contas,
        'criativos_7d_resumo': criativos_cnt,
        'campanhas_hoje_total': camp_cnt['n'] if camp_cnt else 0,
        'clickup_etapas': etapas,
        'clickup_editores': editores,
        'clickup_cards_total': cards_cnt['n'] if cards_cnt else 0,
        'semanas_planilhas': semanas,
    }


def gerar_semanas_js_do_postgres() -> str:
    with db_conn() as conn, conn.cursor() as cur:
        cur.execute('SELECT * FROM semanas_planilhas ORDER BY inicio;')
        planilhas = cur.fetchall()
        cur.execute('SELECT * FROM semanas_criativos ORDER BY id;')
        rows = cur.fetchall()
    if not planilhas:
        raise RuntimeError('Tabela semanas_planilhas vazia.')
    by_week: dict[str, dict[str, list]] = {p['semana_id']: {'abo_cbo': [], 'subidos': []} for p in planilhas}
    for r in rows:
        item = {
            'nome': r['nome'],
            'contas': [c.strip() for c in (r['contas_csv'] or '').split(',') if c.strip()],
            'estrutura': r['estrutura'],
            'status_fonte': r['status_fonte'] or '',
            'vendas': int(r['vendas']),
            'roas': float(r['roas']),
            'gastos': float(r['gastos_brl']),
            'faturamento': float(r['faturamento_brl']),
            'lucro': float(r['lucro_brl']),
            'hook': float(r['hook_pct']) if r['hook_pct'] is not None else None,
            'retencao': float(r['retencao_pct']) if r['retencao_pct'] is not None else None,
            'copy': r['copywriter'] or 'Tiago Neiva',
            'editor': r['editor'] or '',
            'card': '',
            'familia': '',
            'vinculo': 'planilha',
            'fonte_aba': r['fonte_aba'],
            'fonte_linha': int(r['fonte_linha']),
        }
        by_week[r['semana_id']][r['conjunto']].append(item)
    weeks = []
    for p in planilhas:
        wid = p['semana_id']
        sub = by_week[wid]['subidos']
        weeks.append({
            'id': wid,
            'rotulo': p['rotulo'],
            'inicio': str(p['inicio']),
            'fim': str(p['fim']),
            'arquivo': p['arquivo'],
            'pasta': p['pasta_url'],
            'aba': p['aba_principal'],
            'resumo': p['resumo_fonte'],
            'criativos': by_week[wid]['abo_cbo'],
            'subidos': sub,
            'validados': [x for x in sub if 'Validado' in (x['status_fonte'] or '')],
        })
    return '/* Servido em tempo real do PostgreSQL 16 (semanas_planilhas + semanas_criativos) */\nwindow.MUNDOFIT_REAL.semanas = ' + json.dumps(weeks, ensure_ascii=False, separators=(',', ':')) + ';\n'


def gerar_dados_reais_js_do_postgres() -> str:
    raw = (PUBLIC_DIR / 'mundo-fit-dados-reais.js').read_text(encoding='utf-8')
    idx = raw.index('window.MUNDOFIT_REAL = ') + len('window.MUNDOFIT_REAL = ')
    base_data = json.loads(raw[idx:].rstrip(';\n'))
    with db_conn() as conn, conn.cursor() as cur:
        cur.execute('SELECT * FROM utmify_periodos;')
        period_rows = cur.fetchall()
        cur.execute('SELECT * FROM utmify_produtos_periodo ORDER BY id;')
        products = cur.fetchall()
        cur.execute('SELECT * FROM utmify_fontes_periodo ORDER BY id;')
        sources = cur.fetchall()
        cur.execute('SELECT dados, extraido_em FROM utmify_relatorios_diarios ORDER BY data;')
        financial_rows = cur.fetchall()
        cur.execute('SELECT * FROM utmify_diario ORDER BY data_curta;')
        diario_rows = cur.fetchall()
        cur.execute('SELECT * FROM criativos_7d ORDER BY vendas_7d DESC, lucro_7d_brl DESC;')
        criativos_rows = cur.fetchall()
        cur.execute('SELECT * FROM utmify_contas_meta ORDER BY gastos_7d_brl DESC;')
        contas_rows = cur.fetchall()
        cur.execute('SELECT * FROM utmify_campanhas_hoje ORDER BY id;')
        camp_rows = cur.fetchall()
        cur.execute('SELECT * FROM clickup_cards ORDER BY id;')
        cards_rows = cur.fetchall()
    for r in period_rows:
        item = base_data['periodos'][r['periodo_id']]
        mapping = {'vendas':'vendas_aprovadas','bruto':'faturamento_bruto_brl','liquido':'faturamento_liquido_brl','gastos':'gastos_anuncios_brl','lucro':'lucro_liquido_brl','roas':'roas','margem':'margem_pct','cpa':'cpa_brl','reembolso':'reembolso_pct','chargeback':'chargeback_pct'}
        item.update({k:float(r[col]) if r[col] is not None else None for k,col in mapping.items()})
        item['vendas'] = int(r['vendas_aprovadas'])
        item['produtos'] = [{'produto':v['produto'],'vendas':v['vendas'],'share_pct':float(v['share_pct'])} for v in products if v['periodo_id']==r['periodo_id']]
        item['fontes'] = [{'fonte':v['fonte'],'vendas':v['vendas'],'share_pct':float(v['share_pct'])} for v in sources if v['periodo_id']==r['periodo_id']]
        item['funil'] = {k:r[col] for k,col in {'cliques':'cliques','vis_pagina':'visitas_pagina','ics':'checkouts_iniciados','vendas_iniciadas':'vendas_iniciadas','vendas_aprovadas':'vendas_aprovadas'}.items()}
        item['aprovacao'] = {k:float(r[col]) if r[col] is not None else None for k,col in {'pix':'aprovacao_pix_pct','cartao':'aprovacao_cartao_pct','boleto':'aprovacao_boleto_pct'}.items()}
    base_data['__fonte_runtime'] = 'PostgreSQL 16'
    base_data['diario'] = [
        {
            'data': r['data_curta'],
            'dia': r['dia_semana'],
            'vendas': int(r['vendas']),
            'liquido': float(r['faturamento_liquido_brl']),
            'gastos': float(r['gastos_brl']),
            'lucro': float(r['lucro_brl']),
            'roas': float(r['roas']),
        }
        for r in diario_rows
    ]
    base_data['criativos'] = [
        {
            'nome': r['nome'],
            'contas': [c.strip() for c in (r['contas_csv'] or '').split(',') if c.strip()],
            'familia': int(r['familia_ad']),
            'card': r['card_clickup'] or '',
            'vinculo': r['vinculo'],
            'copy': r['copywriter'] or 'Tiago Neiva',
            'editor': r['editor'] or '',
            'vendas': int(r['vendas_7d']),
            'gastos': float(r['gastos_7d_brl']),
            'faturamento': float(r['faturamento_7d_brl']),
            'lucro': float(r['lucro_7d_brl']),
            'roas': float(r['roas_7d']),
            'hook': float(r['hook_pct']) if r['hook_pct'] is not None else None,
            'retencao': float(r['retencao_pct']) if r['retencao_pct'] is not None else None,
        }
        for r in criativos_rows
    ]
    base_data['contas_meta'] = [
        {
            'id_conta': r['id_conta'],
            'conta': r['conta'],
            'status': r['status'],
            'gasto_historico': float(r['gasto_historico_brl']),
            'vendas_7d': int(r['vendas_7d']),
            'gastos_7d': float(r['gastos_7d_brl']),
            'faturamento_7d': float(r['faturamento_7d_brl']),
            'lucro_7d': float(r['lucro_7d_brl']),
            'roas_7d': float(r['roas_7d']) if r['roas_7d'] is not None else None,
        }
        for r in contas_rows
    ]
    if camp_rows:
        base_data['campanhas_hoje']['top'] = [
            {
                'campanha': r['campanha'],
                'conta': r['conta'],
                'vendas': int(r['vendas']),
                'gastos': float(r['gastos_brl']),
                'faturamento': float(r['faturamento_brl']),
                'lucro': float(r['lucro_brl']),
                'roas': float(r['roas']) if r['roas'] is not None else 0.0,
            }
            for r in camp_rows
        ]
    if cards_rows:
        base_data['producao']['cards'] = [
            {
                'nome': r['nome'],
                'status': r['status'],
                'editores': [e.strip() for e in (r['editores_csv'] or '').split(',') if e.strip()],
                'criado': r['criado_iso'],
                'atualizado': r['atualizado_iso'],
            }
            for r in cards_rows
        ]
    from dados.conciliar_relatorios import aplicar_relatorios
    aplicar_relatorios(base_data, [r['dados'] for r in financial_rows], max((r['extraido_em'] for r in financial_rows), default=''))
    return '/* Servido em tempo real do PostgreSQL 16 */\nwindow.MUNDOFIT_REAL = ' + json.dumps(base_data, ensure_ascii=False, separators=(',', ':')) + ';\n'


ALLOWED_EXTENSIONS = {'.html', '.css', '.js', '.svg', '.png', '.ico', '.webmanifest', '.dmg', '.zip'}


class MundoFitHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(PUBLIC_DIR), **kwargs)

    def _send_json(self, payload: object, code: int = 200) -> None:
        raw = json.dumps(payload, ensure_ascii=False, default=str, indent=2).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(raw)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(raw)

    def _is_allowed_static(self, url_path: str) -> bool:
        clean = unquote(url_path).lstrip('/')
        if not clean or '/' in clean or chr(92) in clean or clean.startswith('.'):
            return False
        ext = Path(clean).suffix.lower()
        return ext in ALLOWED_EXTENSIONS

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path in ('/', '/index.html'):
            self.send_response(302)
            self.send_header('Location', '/referencia-visual.html')
            self.end_headers()
            return
        if parsed.path == '/api/health':
            db_ok = False
            db_err = None
            try:
                with db_conn() as conn, conn.cursor() as cur:
                    cur.execute('SELECT COUNT(*) AS n FROM criativos_7d;')
                    row = cur.fetchone()
                    db_ok = bool(row and row['n'] > 0)
            except Exception as exc:  # noqa: BLE001
                db_err = str(exc)
            self._send_json({'status': 'ok', 'postgres_conectado': db_ok, 'erro_postgres': db_err})
            return
        if parsed.path == '/api/postgres/resumo':
            try:
                self._send_json(consultar_postgres_resumo())
            except Exception as exc:  # noqa: BLE001
                self._send_json({'status': 'erro', 'detalhe': str(exc)}, code=500)
            return
        if parsed.path == '/api/adk/auditoria':
            try:
                from agente.agente_mundo_fit import (
                    auditar_lacuna_atribuicao,
                    consultar_producao_clickup,
                    consultar_ranking_criativos,
                    consultar_resumo_periodo,
                )

                self._send_json(
                    {
                        'status': 'ok',
                        'agente': 'mundo_fit_operacao',
                        'resumo_outubro': consultar_resumo_periodo('outubro'),
                        'auditoria_7d': auditar_lacuna_atribuicao(),
                        'ranking_criativos_7d': consultar_ranking_criativos(),
                        'producao_clickup': consultar_producao_clickup(),
                    }
                )
            except Exception as exc:  # noqa: BLE001
                self._send_json({'status': 'erro', 'detalhe': str(exc)}, code=500)
            return
        if parsed.path in ('/mundo-fit-dados-reais.js', '/mundo-fit-semanas.js'):
            try:
                js_body = (
                    gerar_dados_reais_js_do_postgres()
                    if parsed.path == '/mundo-fit-dados-reais.js'
                    else gerar_semanas_js_do_postgres()
                ).encode('utf-8')
                self.send_response(200)
                self.send_header('Content-Type', 'application/javascript; charset=utf-8')
                self.send_header('Content-Length', str(len(js_body)))
                self.send_header('X-MundoFit-Source', 'PostgreSQL-16')
                self.send_header('Cache-Control', 'no-store')
                self.end_headers()
                self.wfile.write(js_body)
                return
            except Exception:  # Falha explícita: não servir silenciosamente uma cópia antiga.
                self._send_json({'status':'indisponivel','mensagem':'Não foi possível carregar o banco. Tente novamente.'}, code=503)
                return
        if not self._is_allowed_static(parsed.path):
            self._send_json({'status': 'proibido', 'mensagem': 'Acesso restrito apenas aos ativos publicos da interface.'}, code=403)
            return
        super().do_GET()

    def do_HEAD(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path in ('/', '/index.html', '/api/health', '/api/postgres/resumo', '/api/adk/auditoria') or self._is_allowed_static(parsed.path):
            super().do_HEAD()
            return
        self.send_response(403)
        self.end_headers()


def main() -> None:
    port = int(os.environ.get('PORT', '8780'))
    server = ThreadingHTTPServer(('0.0.0.0', port), MundoFitHandler)
    print(f'Mundo FIT Docker Server ativo em http://0.0.0.0:{port}/referencia-visual.html', flush=True)
    server.serve_forever()


if __name__ == '__main__':
    main()
