/* Criativos do Mundo FIT com dados reais da Utmify (7 dias, 22/10 a 28/10/2026) cruzados com o ClickUp.
   Front e upsell reais da Utmify. Score: 40% vendas rumo à validação, 40% ROAS até 3x, 20% lucro comparado ao melhor criativo.
   Tiers: regra das planilhas da Thaix. Ícones: Fluent 2 Regular. */
(() => {
  const ICONS = {"Edit16Regular": ["M14.24 1.76a2.6 2.6 0 0 0-3.71 0L2.66 9.64q-.57.57-.78 1.35l-.86 3.39a.5.5 0 0 0 .6.6l3.39-.86q.78-.21 1.35-.78l7.88-7.87a2.6 2.6 0 0 0 0-3.7m-3 .71a1.62 1.62 0 1 1 2.29 2.3l-.78.77-2.3-2.29zM9.75 3.96l2.3 2.29-6.4 6.39q-.37.37-.89.5l-2.57.67.66-2.57q.14-.52.51-.9z"], "VideoClip16Regular": ["M6.5 5.82v4.36c0 .25.27.4.49.27l3.26-1.99a.54.54 0 0 0 0-.92l-3.26-2a.32.32 0 0 0-.49.28M4.5 3A2.5 2.5 0 0 0 2 5.5v5A2.5 2.5 0 0 0 4.5 13h7a2.5 2.5 0 0 0 2.5-2.5v-5A2.5 2.5 0 0 0 11.5 3zM3 5.5C3 4.67 3.67 4 4.5 4h7c.83 0 1.5.67 1.5 1.5v5c0 .83-.67 1.5-1.5 1.5h-7A1.5 1.5 0 0 1 3 10.5z"], "Megaphone16Regular": ["M15 3.5c0-1.02-1-1.75-1.98-1.42l-11 3.72A1.5 1.5 0 0 0 1 7.22v1.56c0 .65.4 1.22 1.02 1.42l1.98.68V12a3 3 0 0 0 5.87.87l3.15 1.07A1.5 1.5 0 0 0 15 12.5zm-1.66-.47a.5.5 0 0 1 .66.47v9.01a.5.5 0 0 1-.66.48l-11-3.73A.5.5 0 0 1 2 8.78V7.22c0-.22.14-.4.34-.48zm-4.42 9.52A2 2 0 0 1 5 12v-.78z"], "ArrowSortDown16Regular": ["M7.15 13.85c.2.2.5.2.7 0l3-3a.5.5 0 0 0-.7-.7L8 12.29V2.5a.5.5 0 0 0-1 0v9.8l-2.15-2.15a.5.5 0 0 0-.7.7z"], "ArrowSortUp16Regular": ["M7.15 2.15c.2-.2.5-.2.7 0l3 3a.5.5 0 0 1-.7.7L8 3.71v9.79a.5.5 0 0 1-1 0V3.7L4.85 5.86a.5.5 0 1 1-.7-.7z"], "ArrowUp16Regular": ["M7.5 13.5a.5.5 0 0 0 1 0V3.8l3.63 4.03a.5.5 0 0 0 .74-.66l-4.5-5a.5.5 0 0 0-.74 0l-4.5 5a.5.5 0 0 0 .74.66L7.5 3.8z"], "ArrowDown16Regular": ["M8.5 2.5a.5.5 0 1 0-1 0v9.7L3.87 8.17a.5.5 0 1 0-.74.66l4.5 5a.5.5 0 0 0 .74 0l4.5-5a.5.5 0 0 0-.74-.66L8.5 12.2z"], "Dismiss24Regular": ["m4.4 4.55.07-.08a.75.75 0 0 1 .98-.07l.08.07L12 10.94l6.47-6.47a.75.75 0 1 1 1.06 1.06L13.06 12l6.47 6.47c.27.27.3.68.07.98l-.07.08a.75.75 0 0 1-.98.07l-.08-.07L12 13.06l-6.47 6.47a.75.75 0 0 1-1.06-1.06L10.94 12 4.47 5.53a.75.75 0 0 1-.07-.98l.07-.08z"], "Print24Regular": ["M15.75 3C17 3 18 4 18 5.25V6h.75C20.55 6 22 7.46 22 9.25v6c0 1.24-1 2.25-2.24 2.25H18v1.25c0 1.24-1 2.25-2.25 2.25h-7.5C7.01 21 6 20 6 18.75V17.5H4.25c-1.24 0-2.25-1-2.25-2.25v-6C2 7.45 3.46 6 5.25 6H6v-.75C6 4.01 7 3 8.25 3zm0 10.5h-7.5a.75.75 0 0 0-.75.75v4.5c0 .41.34.75.75.75h7.5c.41 0 .75-.34.75-.75v-4.5a.75.75 0 0 0-.75-.75m3-6H5.25c-.97 0-1.75.79-1.75 1.75v6c0 .41.34.75.75.75H6v-1.75C6 13.01 7 12 8.25 12h7.5c1.24 0 2.25 1 2.25 2.25V16h1.78c.4-.01.73-.34.73-.75v-6c0-.96-.8-1.75-1.76-1.75m-3-3h-7.5a.75.75 0 0 0-.75.75V6h9v-.75a.75.75 0 0 0-.75-.75"], "Warning16Regular": ["M5.82 2.28a2.5 2.5 0 0 1 4.36 0l4.5 8A2.5 2.5 0 0 1 12.5 14h-9a2.5 2.5 0 0 1-2.18-3.72zm3.49.48a1.5 1.5 0 0 0-2.62 0l-4.5 8a1.5 1.5 0 0 0 1.31 2.24h9a1.5 1.5 0 0 0 1.3-2.23zM8 9.5A.75.75 0 1 1 8 11a.75.75 0 0 1 0-1.5M8 5c.28 0 .5.22.5.5V8a.5.5 0 0 1-1 0V5.5c0-.28.22-.5.5-.5"], "ArrowSwap24Regular": ["m14.78 2.22 4.5 4.5c.26.26.29.68.07.97l-.07.08-4.5 4.5a.75.75 0 0 1-1.13-.97l.07-.08L16.94 8H5.24a.75.75 0 0 1-.74-.65v-.1c0-.38.27-.7.64-.75h11.8l-3.22-3.22a.75.75 0 0 1-.07-.98l.07-.08a.75.75 0 0 1 .98-.07zl4.5 4.5zm4.72 14.43v.1c0 .38-.28.7-.64.74l-.1.01H7.06l3.22 3.22c.27.27.3.68.08.98l-.08.08a.75.75 0 0 1-.97.07l-.09-.07-4.5-4.5a.75.75 0 0 1-.07-.97l.07-.09 4.5-4.5a.75.75 0 0 1 1.14.98l-.08.08L7.07 16h11.69c.38 0 .7.28.74.65v.1z"]};
  const icon = (n) => '<svg viewBox="0 0 24 24" aria-hidden="true">' + ICONS[n].map((d) => '<path d="' + d + '"/>').join('') + '</svg>';
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
  const byId = (id) => document.getElementById(id);

  const R = window.MUNDOFIT_REAL;
  const VALID_SALES = 10, VALID_ROAS = 1.5, ROAS_CAP = 3; /* regra das planilhas da Thaix, até Pedro Ivo Torres definir */
  const tierOf = (c) => {
    if (c.profit < 0) return ['Saldo parcial negativo', 'bad'];
    if (c.sales >= VALID_SALES && c.roas >= VALID_ROAS) return ['Critério numérico atingido', 'gold'];
    return c.profit > 0 ? ['Lucrativo', 'good'] : ['Sem lucro', 'warn'];
  };
  const srcLabel = (a) => a.fonte_aba ? (a.semana ? a.semana + ' · ' : '') + a.fonte_aba + ', linha ' + a.fonte_linha : (a.vinculo === 'normalizado' ? 'Card norm. ' + a.card : a.card ? 'Card ' + a.card : 'Família AD ' + a.familia);
  let base = [];
  function loadBase(rows) {
  base = rows.map((a) => ({ name: a.nome + (a.estrutura ? ' · ' + a.estrutura : '') + (a.semana ? ' · ' + a.semana : ''), week: a.semana || '', statusFonte: a.status_fonte, format: a.contas.length > 1 ? a.contas.length + ' contas' : a.contas[0], source: srcLabel(a), vinculo: a.vinculo, exact: !!a.card, copy: a.copy, editor: a.editor, sales: a.vendas, revenue: a.faturamento, spend: a.gastos, profit: a.lucro, roas: a.roas, cac: a.vendas ? a.gastos / a.vendas : 0, hook: a.hook, ret: a.retencao }));
  const best = Math.max(1, ...base.map((c) => c.profit));
  base.forEach((c) => {
    c.validation = (Math.min(c.sales / VALID_SALES, 1) + Math.min(c.roas / VALID_ROAS, 1)) / 2;
    c.score = Math.round(40 * Math.min(c.sales / VALID_SALES, 1) + 40 * Math.min(c.roas / ROAS_CAP, 1) + 20 * Math.max(c.profit / best, 0));
    if (c.vinculo === 'planilha') {
      const stTxt = c.statusFonte || 'Sem status na planilha';
      c.tier = [stTxt, stTxt.includes('Validado') ? 'gold' : c.profit < 0 ? 'bad' : 'warn'];
      c.validation = null;
    } else {
      c.tier = c.statusFonte ? [c.statusFonte, c.statusFonte.includes('Validado') ? 'gold' : c.profit < 0 ? 'bad' : 'warn'] : tierOf(c);
    }
  });

  }
  loadBase(R.criativos);
  const COLS = [
    ['score', 'Score experimental'], ['name', 'Criativo'], ['copy', 'Copy'], ['editor', 'Editor'], ['tier', 'Tier'],
    ['sales', 'Vendas'], ['revenue', 'Faturamento'], ['spend', 'Investido'], ['profit', 'Saldo rastreado'], ['roas', 'ROAS'], ['cac', 'CAC'], ['hook', 'Hook'], ['ret', 'Retenção'], ['validation', 'Validação']
  ];
  const NUM = ['score', 'sales', 'revenue', 'spend', 'profit', 'roas', 'cac', 'hook', 'ret', 'validation'];
  const st = { sort: 'score', dir: -1, shown: 10, pick: [], person: 'all', period: 'sete_dias' };
  const brl = (v) => (v < 0 ? 'BRL -' : 'BRL ') + Math.abs(Math.round(v)).toLocaleString('pt-BR');
  const brl2 = (v) => 'BRL ' + v.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const x2 = (v) => v.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + 'x';
  const pc = (v) => v == null ? 'Status da fonte' : Math.round(v * 100) + '%';
  const who = (name, ic) => (name ? '<span class="cf-who">' + icon(ic) + esc(name) + '</span>' : '<span class="cf-who unknown" title="Sem card exato da variação no ClickUp">' + icon(ic) + '?</span>');
  const pp = (v) => (v == null ? '<span class="muted">Sem dado</span>' : v.toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + '%');

  function sorted() {
    const k = st.sort;
    return base.filter((c) => (st.period === 'sete_dias' || st.period === 'outubro' || R.semanas.some((w) => w.id === st.period)) && (st.person === 'all' || c.copy === st.person || c.editor === st.person)).sort((a, b) => {
      const va = k === 'tier' ? a.tier[0] : a[k], vb = k === 'tier' ? b.tier[0] : b[k];
      return (typeof va === 'number' ? va - vb : String(va).localeCompare(String(vb), 'pt-BR')) * st.dir;
    });
  }
  function render() {
    byId('cf-head').innerHTML = '<th scope="col"><span class="sr-only">Selecionar</span></th>' + COLS.map(([k, l]) => {
      const on = st.sort === k;
      return '<th scope="col" class="' + (NUM.includes(k) && k !== 'score' ? 'right' : '') + '" aria-sort="' + (on ? (st.dir < 0 ? 'descending' : 'ascending') : 'none') + '"><button type="button" class="cf-sort' + (on ? ' on' : '') + '" data-k="' + k + '">' + l + (on ? icon(st.dir < 0 ? 'ArrowSortDown16Regular' : 'ArrowSortUp16Regular') : '') + '</button></th>';
    }).join('');
    const list = sorted();
    byId('cf-body').innerHTML = list.slice(0, st.shown).map((c) => {
      const picked = st.pick.includes(c.name);
      return '<tr' + (picked ? ' class="picked"' : '') + '><td><input type="checkbox" class="cf-pick" data-name="' + esc(c.name) + '" aria-label="Selecionar ' + esc(c.name) + ' para comparar"' + (picked ? ' checked' : '') + (!picked && st.pick.length >= 2 ? ' disabled' : '') + '></td>' +
        '<td><span class="cf-score s' + (c.score >= 70 ? 'hi' : c.score >= 40 ? 'mid' : 'lo') + ' num">' + c.score + '</span></td>' +
        '<th scope="row"><span class="cf-name">' + esc(c.name) + '</span><span class="cf-chips"><span class="cf-chip fmt">' + esc(c.format) + '</span><span class="cf-chip src" title="' + (c.exact ? 'Vínculo comprovado no ClickUp' : 'Sem card único da variação no ClickUp') + '">' + esc(c.source) + '</span></span></th>' +
        '<td>' + who(c.copy, 'Edit16Regular') + '</td><td>' + who(c.editor, 'VideoClip16Regular') + '</td>' +
        '<td><span class="cf-tier ' + c.tier[1] + '">' + c.tier[0] + '</span></td>' +
        '<td class="right num">' + c.sales.toLocaleString('pt-BR') + '</td><td class="right num">' + brl(c.revenue) + '</td><td class="right num">' + brl(c.spend) + '</td>' +
        '<td class="right num ' + (c.profit < 0 ? 'neg' : 'pos') + '">' + brl(c.profit) + '</td><td class="right num">' + x2(c.roas) + '</td><td class="right num">' + brl2(c.cac) + '</td>' +
        '<td class="right num">' + pp(c.hook) + '</td><td class="right num">' + pp(c.ret) + '</td>' +
        '<td><span class="cf-val"><span class="cf-val-bar"><i style="width:' + (c.validation * 100).toFixed(0) + '%"></i></span><span class="num">' + pc(c.validation) + '</span></span></td></tr>';
    }).join('');
    const week = R.semanas.find((w) => w.id === st.period);
    byId('cf-scope').disabled = !week && st.period !== 'outubro';
    byId('cf-coverage').textContent = week ? list.length + ' linhas no conjunto selecionado, semana ' + week.rotulo + '. ' + week.resumo + '. A taxa é da aba ' + week.aba + ', com outro conjunto de criativos. Status preservado da planilha; o mesmo criativo pode ter resultado diferente em ABO e CBO.' : st.period === 'sete_dias' ? list.length + ' criativos nesta amostra. A extração não inclui todos os anúncios. Copy: Tiago Neiva, conforme confirmação da equipe. Editor: vínculo comprovado no ClickUp.' : st.period === 'outubro' ? list.length + ' linhas das semanas completas de 05/10 a 25/10. Cobertura parcial do mês: faltam 01/10 a 04/10 e 26/10 a 28/10. Cada linha mantém sua semana; não é um resultado mensal completo.' : 'Não há uma planilha inteiramente contida neste mês. A semana de 28/09 a 04/10 está disponível no seletor; ela não pode ser dividida por dia sem os dados de cada anúncio.';
    const rest = list.length - st.shown;
    byId('cf-more').hidden = rest <= 0;
    byId('cf-more').textContent = 'Mostrar mais (' + rest + ')';
    byId('cf-bar').hidden = st.pick.length === 0;
    byId('cf-bar-text').textContent = st.pick.length === 1 ? '1 criativo selecionado. Escolha mais 1.' : st.pick.length + ' criativos selecionados.';
    byId('cf-compare').disabled = st.pick.length !== 2;
    document.querySelectorAll('.cf-sort').forEach((b) => b.addEventListener('click', () => { st.dir = st.sort === b.dataset.k ? -st.dir : -1; st.sort = b.dataset.k; render(); }));
    document.querySelectorAll('.cf-pick').forEach((b) => b.addEventListener('change', () => { const n = b.dataset.name; st.pick = b.checked ? [...st.pick, n].slice(-2) : st.pick.filter((x) => x !== n); render(); }));
  }

  /* comparação lado a lado: vence quem tem o maior valor, exceto investido e CAC, em que vence o menor */
  const METRICS = [['score', 'Score', String, 1], ['roas', 'ROAS', x2, 1], ['sales', 'Vendas', (v) => v.toLocaleString('pt-BR'), 1], ['revenue', 'Faturamento', brl, 1], ['profit', 'Lucro', brl, 1], ['spend', 'Investido', brl, -1], ['cac', 'CAC', brl2, -1], ['hook', 'Hook', (v) => (v == null ? 'Sem dado' : pc(v / 100)), 1], ['validation', 'Validação', pc, 1]];
  function compare() {
    const [a, b] = st.pick.map((n) => base.find((c) => c.name === n));
    const comparable = a.week === b.week;
    let wa = 0, wb = 0;
    const rows = METRICS.map(([k, l, f, better]) => {
      const d = comparable && typeof a[k] === 'number' && typeof b[k] === 'number' ? (a[k] - b[k]) * better : 0;
      if (d > 0) wa++; else if (d < 0) wb++;
      const mark = (win) => (d === 0 ? '' : '<span class="cf-mark ' + (win ? 'win' : 'lose') + '">' + icon(win ? 'ArrowUp16Regular' : 'ArrowDown16Regular') + '<span class="sr-only">' + (win ? 'vence' : 'perde') + '</span></span>');
      return '<tr><td class="right num' + (d > 0 ? ' win' : '') + '">' + f(a[k]) + mark(d > 0) + '</td><th scope="row">' + l + '</th><td class="num' + (d < 0 ? ' win' : '') + '">' + mark(d < 0) + f(b[k]) + '</td></tr>';
    }).join('');
    const verdict = !comparable ? 'Períodos diferentes: comparação descritiva, sem classificação de vencedor.' : wa === wb ? 'Empate: ' + wa + ' métricas para cada lado.' : (wa > wb ? a.name : b.name) + ' tem valor superior em ' + Math.max(wa, wb) + ' de ' + METRICS.length + ' métricas.';
    byId('cf-dialog-body').innerHTML = '<div class="cf-vs"><div><b>' + esc(a.name) + '</b><span class="cf-chip fmt">' + esc(a.format) + '</span><span class="cf-wins' + (wa > wb ? ' lead' : '') + '">' + wa + ' vitórias</span></div><span class="cf-vs-x">vs</span><div><b>' + esc(b.name) + '</b><span class="cf-chip fmt">' + esc(b.format) + '</span><span class="cf-wins' + (wb > wa ? ' lead' : '') + '">' + wb + ' vitórias</span></div></div><table class="cf-cmp"><caption class="sr-only">Comparação de ' + esc(a.name) + ' e ' + esc(b.name) + '</caption><tbody>' + rows + '</tbody></table><p class="cf-verdict">' + esc(verdict) + '</p>';
    byId('cf-dialog').showModal();
  }

  byId('cf-compare').insertAdjacentHTML('afterbegin', icon('ArrowSwap24Regular'));
  byId('cf-close').innerHTML = icon('Dismiss24Regular');
  byId('cf-print').insertAdjacentHTML('afterbegin', icon('Print24Regular'));
  byId('cf-more').addEventListener('click', () => { st.shown += 10; render(); });
  byId('cf-clear').addEventListener('click', () => { st.pick = []; render(); });
  byId('cf-compare').addEventListener('click', compare);
  byId('cf-close').addEventListener('click', () => byId('cf-dialog').close());
  byId('cf-print').addEventListener('click', () => window.print());
  /* front e upsell: produtos da Utmify. Front = Desafio Hiit Dance; upsell = ACESSO VIP: Desafio Hiit Dance */
  const FU = [['Setembro', R.periodos.setembro], ['Outubro', R.periodos.outubro], ['7 dias', R.periodos.sete_dias]].map(([l, p]) => {
    const f = p.produtos.find((x) => x.produto === 'Desafio Hiit Dance'), u = p.produtos.find((x) => x.produto === 'ACESSO VIP: Desafio Hiit Dance');
    return { l, front: f.vendas, fs: f.share_pct, up: u.vendas, us: u.share_pct, rate: u.vendas / f.vendas };
  });
  byId('cf-fu').innerHTML = FU.map((x) => '<div class="panel cr-kpi"><span class="cr-kpi-label">' + x.l + '</span><strong class="num">' + (x.rate * 100).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + '%</strong><small>' + x.up.toLocaleString('pt-BR') + ' upsells sobre ' + x.front.toLocaleString('pt-BR') + ' fronts · front ' + x.fs.toLocaleString('pt-BR') + '% e upsell ' + x.us.toLocaleString('pt-BR') + '% do volume</small></div>').join('');
  byId('cf-period').insertAdjacentHTML('beforeend', R.semanas.map((w) => '<option value="' + w.id + '">Semana ' + w.rotulo + '</option>').join(''));
  const allPeople = [...new Set([
    ...R.criativos.flatMap((c) => [c.copy, c.editor]),
    ...(R.semanas || []).flatMap((w) => [...w.criativos, ...w.subidos].flatMap((c) => [c.copy, c.editor])),
    ...((R.producao && R.producao.editores) || []).map((e) => e.nome)
  ].filter(Boolean))].sort((a, b) => a.localeCompare(b, 'pt-BR'));
  byId('cf-person').innerHTML = '<option value="all">Todos os responsáveis</option>' + allPeople.map((n) => '<option>' + esc(n) + '</option>').join('');
  byId('cf-person').addEventListener('change', (e) => { st.person = e.target.value; st.shown = 10; st.pick = []; render(); });
  function updatePeriod() {
    const week=R.semanas.find(w=>w.id===st.period), scope=byId('cf-scope').value==='subidos'?'subidos':'criativos';
    const rows=week?week[scope]:st.period==='outubro'?R.semanas.filter(w=>w.inicio>='2026-10-01'&&w.fim<='2026-10-28').flatMap(w=>w[scope].map(a=>({...a,semana:w.rotulo}))):st.period==='sete_dias'?R.criativos:[];
    loadBase(rows);st.shown=10;st.pick=[];render();
  }
  byId('cf-period').addEventListener('change',e=>{st.period=e.target.value;updatePeriod();});
  byId('cf-scope').addEventListener('change',updatePeriod);
  render();
})();
