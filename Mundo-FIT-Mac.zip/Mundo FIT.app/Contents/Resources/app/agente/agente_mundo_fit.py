#!/usr/bin/env python3
"""Agente operacional do Mundo FIT construído no padrão Google Antigravity SDK (ADK).

Integra as extrações auditadas da Utmify (5 Vault/2026-10-28 Utmify) e do ClickUp
(5 Vault/2026-10-28 Setup Nomad/ClickUp/tarefas-thaix.json) com ferramentas tipadas.

Uso:
  python3 -I agente/agente_mundo_fit.py --auditoria
"""
from __future__ import annotations

import argparse
import csv
import json
import os
from pathlib import Path
from typing import Any

try:
    from google.antigravity import Agent, LocalAgentConfig, ToolContext
except ImportError:  # Permite inspeção local dos dados mesmo fora do runtime do SDK
    Agent = None  # type: ignore[assignment]
    LocalAgentConfig = None  # type: ignore[assignment]
    ToolContext = Any  # type: ignore[misc,assignment]

PUBLIC_DIR = Path(__file__).resolve().parents[1]
ROOT = Path(__file__).resolve().parents[4] if len(Path(__file__).resolve().parents) > 4 else PUBLIC_DIR
UTM_DIR = ROOT / '5 Vault' / '2026-10-28 Utmify'
CLK_FILE = ROOT / '5 Vault' / '2026-10-28 Setup Nomad' / 'ClickUp' / 'tarefas-thaix.json'
REAL_JS = PUBLIC_DIR / 'mundo-fit-dados-reais.js'
SEMANAS_JS = PUBLIC_DIR / 'mundo-fit-semanas.js'


def _carregar_real() -> dict[str, Any]:
    if os.environ.get('MUNDOFIT_PUBLIC_DIR'):
        from docker.servidor_mundo_fit import gerar_dados_reais_js_do_postgres
        texto = gerar_dados_reais_js_do_postgres()
    else:
        texto = REAL_JS.read_text(encoding='utf-8')
    inicio = texto.index('window.MUNDOFIT_REAL = ') + len('window.MUNDOFIT_REAL = ')
    return json.loads(texto[inicio:].rstrip(';\n'))


def consultar_resumo_periodo(periodo: str = 'outubro', tool_context: ToolContext = None) -> dict[str, Any]:
    """Consulta as métricas reais consolidadas da Utmify para um período.

    Args:
        periodo: Período desejado ('hoje', 'sete_dias', 'outubro' ou 'setembro').
    """
    dados = _carregar_real()
    periodos = dados['periodos']
    chave = periodo.lower().strip()
    if chave not in periodos:
        return {'status': 'erro', 'mensagem': f'Período inválido: {periodo}. Use hoje, sete_dias, outubro ou setembro.'}
    p = periodos[chave]
    if tool_context is not None and hasattr(tool_context, 'state'):
        tool_context.state['ultimo_periodo_consultado'] = chave
    return {
        'status': 'ok',
        'painel': dados['painel'],
        'extraido_em': dados['extraido_em'],
        'periodo': chave,
        'vendas_aprovadas': p['vendas'],
        'faturamento_bruto_brl': p.get('bruto'),
        'faturamento_liquido_brl': p['liquido'],
        'gastos_anuncios_brl': p['gastos'],
        'lucro_liquido_brl': p['lucro'],
        'roas': p['roas'],
        'margem_pct': p['margem'],
        'cpa_brl': p['cpa'],
        'aprovacao_pagamento_pct': p['aprovacao'],
        'produtos': p['produtos'],
    }


def auditar_lacuna_atribuicao(tool_context: ToolContext = None) -> dict[str, Any]:
    """Audita a diferença entre o lucro real do painel e a soma atribuída às 9 contas Meta em 7 dias."""
    dados = _carregar_real()
    p7 = dados.get('periodos_anteriores', dados['periodos'])['sete_dias']
    contas = dados['contas_meta']
    vendas_contas = sum(c['vendas_7d'] for c in contas)
    gastos_contas = round(sum(c['gastos_7d'] for c in contas), 2)
    fat_contas = round(sum(c['faturamento_7d'] for c in contas), 2)
    lucro_contas = round(sum(c['lucro_7d'] for c in contas), 2)
    sem_utm = next((f for f in p7['fontes'] if f['fonte'] == 'N/A'), {'vendas': 0, 'share_pct': 0.0})
    resultado = {
        'status': 'ok',
        'periodo': '22/10 a 28/10/2026 (7 dias)',
        'painel_total': {
            'vendas': p7['vendas'],
            'faturamento_liquido_brl': p7['liquido'],
            'gastos_brl': p7['gastos'],
            'lucro_brl': p7['lucro'],
            'roas': p7['roas'],
        },
        'soma_9_contas_meta': {
            'vendas_atribuidas': vendas_contas,
            'faturamento_atribuido_brl': fat_contas,
            'gastos_brl': gastos_contas,
            'lucro_atribuido_brl': lucro_contas,
        },
        'diferenca_nao_atribuida': {
            'vendas_fora_das_contas': p7['vendas'] - vendas_contas,
            'receita_liquida_fora_das_contas_brl': round(p7['liquido'] - fat_contas, 2),
            'vendas_sem_utm_na': sem_utm['vendas'],
            'share_sem_utm_pct': sem_utm['share_pct'],
        },
        'diagnostico': (
            'O gasto das 9 contas Meta bate 100% com o resumo (BRL 139.988,97), mas '
            'BRL 29.740,56 de receita líquida (785 vendas) entram sem vínculo às contas '
            'porque 569 vendas chegaram com utm_source=N/A e o restante veio de backredirect/SMS/orgânico.'
        ),
    }
    if tool_context is not None and hasattr(tool_context, 'state'):
        tool_context.state['ultima_auditoria'] = resultado['diferenca_nao_atribuida']
    return resultado


def consultar_ranking_criativos(
    min_vendas: int = 10,
    min_roas: float = 1.5,
    tool_context: ToolContext = None,
) -> dict[str, Any]:
    """Lista os criativos validados e o ranking real por pessoa nos últimos 7 dias.

    Args:
        min_vendas: Mínimo de vendas aprovadas em 7 dias para validar o criativo.
        min_roas: ROAS mínimo em 7 dias para validar o criativo.
    """
    dados = _carregar_real()
    criativos = dados['criativos']
    validados = [
        c for c in criativos if c['vendas'] >= min_vendas and c['roas'] >= min_roas
    ]
    por_editor: dict[str, dict[str, Any]] = {}
    for c in criativos:
        ed = c['editor']
        if not ed:
            continue
        item = por_editor.setdefault(
            ed,
            {'editor': ed, 'criativos': 0, 'validados': 0, 'vendas': 0, 'gastos_brl': 0.0, 'faturamento_brl': 0.0, 'lucro_brl': 0.0},
        )
        item['criativos'] += 1
        if c['vendas'] >= min_vendas and c['roas'] >= min_roas:
            item['validados'] += 1
        item['vendas'] += c['vendas']
        item['gastos_brl'] = round(item['gastos_brl'] + c['gastos'], 2)
        item['faturamento_brl'] = round(item['faturamento_brl'] + c['faturamento'], 2)
        item['lucro_brl'] = round(item['lucro_brl'] + c['lucro'], 2)
    ranking_editores = sorted(por_editor.values(), key=lambda x: -x['lucro_brl'])
    return {
        'status': 'ok',
        'criterio_validacao': {'min_vendas': min_vendas, 'min_roas': min_roas},
        'total_criativos_pagina_1': len(criativos),
        'com_editor_comprovado': sum(1 for c in criativos if c['editor']),
        'total_validados': len(validados),
        'top_validados': [
            {
                'nome': c['nome'],
                'card_clickup': c['card'],
                'vinculo': c['vinculo'],
                'copy': c['copy'],
                'editor': c['editor'],
                'vendas': c['vendas'],
                'lucro_brl': c['lucro'],
                'roas': c['roas'],
            }
            for c in sorted(validados, key=lambda x: -x['lucro'])[:10]
        ],
        'ranking_editores': ranking_editores,
    }


def consultar_producao_clickup(editor: str = 'todos', tool_context: ToolContext = None) -> dict[str, Any]:
    """Consulta a produção real da lista 6. PRODUÇÃO DE ADS no ClickUp e os gargalos abertos.

    Args:
        editor: Nome do editor ou 'todos' para visão completa.
    """
    dados = _carregar_real()
    prod = dados['producao']
    filtro = editor.strip().lower()
    editores = [
        e for e in prod['editores']
        if filtro in ('todos', 'all', '') or filtro in e['nome'].lower()
    ]
    gargalos = [
        g for g in prod['gargalos']
        if filtro in ('todos', 'all', '') or any(filtro in ed.lower() for ed in g['editores'])
    ]
    return {
        'status': 'ok',
        'lista': prod['lista'],
        'total_cards': prod['total_cards'],
        'etapas_atuais': prod['etapas'],
        'semanas_outubro': prod['semanas'],
        'editores': editores,
        'gargalos_abertos': gargalos[:10],
    }


INSTRUCAO_AGENTE = """Você é o agente operacional do sistema Mundo FIT (operação Nomad Creators / Thaix Santiago).
Regras obrigatórias:
1. Responda sempre em português brasileiro natural, no padrão ASD-STE100 adaptado ao português (frases curtas, diretas e verificáveis).
2. Comece sempre pelo resultado numérico comprovado nas ferramentas.
3. Nunca invente métricas nem atribua autoria quando o card da variação no ClickUp for ambíguo.
4. Tiago Neiva é o único copywriter e cofundador; os demais nomes nos cards de criativos são editores.
5. Nunca use o símbolo monetário proibido; escreva valores sempre com o prefixo BRL (por exemplo, BRL 135.694,02).
"""


def criar_agente_mundo_fit():
    """Instancia o Agent do Google Antigravity SDK (ADK) com as 4 ferramentas reais da operação."""
    if Agent is None:
        raise RuntimeError('Pacote google-antigravity não encontrado neste ambiente Python.')
    return Agent(
        name='mundo_fit_operacao',
        model='gemini-3.8-flash',
        description='Agente de auditoria e operação de tráfego, criativos e produção do Mundo FIT.',
        instruction=INSTRUCAO_AGENTE,
        tools=[
            consultar_resumo_periodo,
            auditar_lacuna_atribuicao,
            consultar_ranking_criativos,
            consultar_producao_clickup,
        ],
    )


def main() -> None:
    parser = argparse.ArgumentParser(description='Agente ADK Mundo FIT')
    parser.add_argument('--auditoria', action='store_true', help='Imprime o diagnóstico completo das 4 ferramentas reais.')
    args = parser.parse_args()
    if args.auditoria:
        relatorio = {
            'agente': 'mundo_fit_operacao',
            'modelo_padrao': 'gemini-3.8-flash',
            'resumo_outubro': consultar_resumo_periodo('outubro'),
            'auditoria_atribuicao_7d': auditar_lacuna_atribuicao(),
            'ranking_criativos_7d': consultar_ranking_criativos(),
            'producao_clickup': consultar_producao_clickup(),
        }
        print(json.dumps(relatorio, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
