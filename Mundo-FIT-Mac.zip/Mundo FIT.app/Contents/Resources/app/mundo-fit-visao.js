/* Visão geral do Mundo FIT com dados reais da Utmify (painel Principal, extração de 28/10/2026 19:05).
   Distribuição de campos do Fahto Champions. Dados: window.MUNDOFIT_REAL, de mundo-fit-dados-reais.js.
   Regras da Utmify: ROAS = faturamento bruto / gastos; lucro = faturamento líquido - gastos. Ícones: Fluent 2 Regular. */
(() => {
  const ICONS = {"CalendarToday24Regular": ["M21 6.25C21 4.45 19.54 3 17.75 3H6.25A3.25 3.25 0 0 0 3 6.25v11.5C3 19.55 4.46 21 6.25 21h4v-1.5h-4c-.97 0-1.75-.78-1.75-1.75V8.5h15v9.25c0 .97-.78 1.75-1.75 1.75h-4V21h4c1.8 0 3.25-1.46 3.25-3.25zM6.25 4.5h11.5c.97 0 1.75.78 1.75 1.75V7h-15v-.75c0-.97.78-1.75 1.75-1.75m7 7.25a1.25 1.25 0 1 1-2.5 0 1.25 1.25 0 0 1 2.5 0m.5 6.56a.75.75 0 0 0 1-1.12l-2.25-2a.75.75 0 0 0-1 0l-2.25 2a.75.75 0 0 0 1 1.12l1-.89v3.83a.75.75 0 1 0 1.5 0v-3.83z"], "History24Regular": ["M12 4.5a7.5 7.5 0 1 1-7.42 6.4c.07-.46-.26-.9-.72-.9-.37 0-.7.26-.76.62Q3 11.3 3 12a9 9 0 1 0 3-6.7V4.24a.75.75 0 0 0-1.5 0v3c0 .41.34.75.75.75h3a.75.75 0 0 0 0-1.5H6.9a7.5 7.5 0 0 1 5.1-2m.5 3.25a.75.75 0 0 0-1.5 0v4.5c0 .41.34.75.75.75h3a.75.75 0 0 0 0-1.5H12.5z"], "DataBarVertical24Regular": ["M5.75 3C6.99 3 8 4 8 5.25v13.5a2.25 2.25 0 1 1-4.5 0V5.25C3.5 4 4.5 3 5.75 3m6.5 4c1.24 0 2.25 1 2.25 2.25v9.5a2.25 2.25 0 1 1-4.5 0v-9.5C10 8 11 7 12.25 7m6.5 4c1.24 0 2.25 1 2.25 2.25v5.5a2.25 2.25 0 1 1-4.5 0v-5.5c0-1.24 1-2.25 2.25-2.25m-13-6.5a.75.75 0 0 0-.75.75v13.5a.75.75 0 0 0 1.5 0V5.25a.75.75 0 0 0-.75-.75m6.5 4a.75.75 0 0 0-.75.75v9.5a.75.75 0 0 0 1.5 0v-9.5a.75.75 0 0 0-.75-.75m6.5 4a.75.75 0 0 0-.75.75v5.5a.75.75 0 0 0 1.5 0v-5.5a.75.75 0 0 0-.75-.75"], "CalendarMonth24Regular": ["M17.75 3C19.55 3 21 4.46 21 6.25v11.5c0 1.8-1.46 3.25-3.25 3.25H6.25A3.25 3.25 0 0 1 3 17.75V6.25C3 4.45 4.46 3 6.25 3zm0 1.5H6.25c-.97 0-1.75.78-1.75 1.75v11.5c0 .97.78 1.75 1.75 1.75h11.5c.97 0 1.75-.78 1.75-1.75V6.25c0-.97-.78-1.75-1.75-1.75m-10 9a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5m4.25 0a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5m-4.25-5a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5m4.25 0a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5m4.25 0a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5"], "CalendarLtr24Regular": ["M17.75 3C19.55 3 21 4.46 21 6.25v11.5c0 1.8-1.46 3.25-3.25 3.25H6.25A3.25 3.25 0 0 1 3 17.75V6.25C3 4.45 4.46 3 6.25 3zm1.75 5.5h-15v9.25c0 .97.78 1.75 1.75 1.75h11.5c.97 0 1.75-.78 1.75-1.75zm-11.75 6a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5m4.25 0a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5m-4.25-4a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5m4.25 0a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5m4.25 0a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5m1.5-6H6.25c-.97 0-1.75.78-1.75 1.75V7h15v-.75c0-.97-.78-1.75-1.75-1.75"], "Trophy24Regular": ["M15.25 2c1.16 0 2.12.88 2.24 2h1.27c.92 0 1.67.7 1.74 1.6v3.15a3.25 3.25 0 0 1-3.06 3.24l-.2.01a5.8 5.8 0 0 1-4.74 3.95v1.55h1.75a3.25 3.25 0 0 1 3.25 3.07v.68c0 .38-.28.7-.64.74l-.1.01h-10a.75.75 0 0 1-.75-.65v-.6a3.25 3.25 0 0 1 3.06-3.24l.18-.01H11v-1.55A5.8 5.8 0 0 1 6.27 12h-.02A3.25 3.25 0 0 1 3 8.75v-3C3 4.78 3.78 4 4.75 4H6c.13-1.12 1.08-2 2.24-2zm-1 17h-5c-.83 0-1.52.58-1.7 1.35l-.03.15h8.47A1.75 1.75 0 0 0 14.4 19zm1-15.5h-7a.75.75 0 0 0-.75.75v6a4.25 4.25 0 0 0 8.5 0v-6a.75.75 0 0 0-.75-.75m3.5 2H17.5v4.98c.8-.11 1.43-.76 1.5-1.58V5.75a.3.3 0 0 0-.18-.24zM6 5.5H4.75a.25.25 0 0 0-.25.25v3c0 .88.65 1.61 1.5 1.73z"], "Cart24Regular": ["M2.5 4.25c0-.41.34-.75.75-.75h.56c.95 0 1.52.64 1.84 1.23.22.4.38.86.5 1.27h12.6c.83 0 1.43.8 1.2 1.6L18.12 14a2.75 2.75 0 0 1-2.64 2H9.53a2.75 2.75 0 0 1-2.65-2.02l-.76-2.78-1.26-4.24v-.01c-.16-.57-.3-1.1-.52-1.5C4.13 5.07 3.96 5 3.8 5h-.56a.75.75 0 0 1-.75-.75m5.07 6.59.75 2.74c.15.54.65.92 1.21.92h5.95c.56 0 1.05-.37 1.2-.9l1.74-6.1H6.59l.97 3.29zM11 19a2 2 0 1 1-4 0 2 2 0 0 1 4 0m-1.5 0a.5.5 0 1 0-1 0 .5.5 0 0 0 1 0m8.5 0a2 2 0 1 1-4 0 2 2 0 0 1 4 0m-1.5 0a.5.5 0 1 0-1 0 .5.5 0 0 0 1 0"], "Money24Regular": ["M10.5 8a3 3 0 1 0 0 6 3 3 0 0 0 0-6M9 11a1.5 1.5 0 1 1 3 0 1.5 1.5 0 0 1-3 0M2 7.25C2 6.01 3 5 4.25 5h12.5C17.99 5 19 6 19 7.25v7.5c0 1.24-1 2.25-2.25 2.25H4.25C3.01 17 2 16 2 14.75zm2.25-.75a.75.75 0 0 0-.75.75V8h.75c.41 0 .75-.34.75-.75V6.5zm-.75 6h.75c1.24 0 2.25 1 2.25 2.25v.75h8v-.75c0-1.24 1-2.25 2.25-2.25h.75v-3h-.75c-1.24 0-2.25-1-2.25-2.25V6.5h-8v.75c0 1.24-1 2.25-2.25 2.25H3.5zm14-4.5v-.75a.75.75 0 0 0-.75-.75H16v.75c0 .41.34.75.75.75zm0 6h-.75a.75.75 0 0 0-.75.75v.75h.75c.41 0 .75-.34.75-.75zm-14 .75c0 .41.34.75.75.75H5v-.75a.75.75 0 0 0-.75-.75H3.5zm.9 3.75A3 3 0 0 0 7 20h10.25A4.75 4.75 0 0 0 22 15.25V10a3 3 0 0 0-1.5-2.6v7.85c0 1.8-1.46 3.25-3.25 3.25z"], "Megaphone24Regular": ["M21.9 5.62q.1.32.1.64v11.48a2.25 2.25 0 0 1-2.9 2.16l-5.5-1.64A4 4 0 0 1 6 16.7V16l-2.4-.71A2.25 2.25 0 0 1 2 13.13v-2.26c0-1 .65-1.87 1.6-2.16l15.5-4.6c1.2-.36 2.45.32 2.8 1.51M7.5 16.44v.06a2.5 2.5 0 0 0 4.62 1.32zm12.04-10.9-15.5 4.61a.75.75 0 0 0-.54.72v2.26c0 .33.22.63.54.72l15.5 4.6a.75.75 0 0 0 .96-.71V6.26a.75.75 0 0 0-.96-.72"], "Wallet24Regular": ["M15.5 13.75c0-.41.34-.75.75-.75h2a.75.75 0 0 1 0 1.5h-2a.75.75 0 0 1-.75-.75M3 5h.01c.13-1.12 1.08-2 2.24-2h11.5C17.99 3 19 4 19 5.25v.84a3.25 3.25 0 0 1 2.5 3.16v8.5c0 1.8-1.46 3.25-3.25 3.25h-12A3.25 3.25 0 0 1 3 17.75zm15.25 2.5H4.5v10.25c0 .97.78 1.75 1.75 1.75h12c.97 0 1.75-.78 1.75-1.75v-8.5c0-.97-.78-1.75-1.75-1.75M17.5 6v-.75a.75.75 0 0 0-.75-.75H5.25a.75.75 0 0 0 0 1.5z"], "ArrowTrending24Regular": ["M13.75 5.5h7.55l.1.01.1.03.06.03q.13.04.22.15l.04.04.04.06.06.09.04.09.02.06.01.07.01.1v7.52a.75.75 0 0 1-1.5.1v-5.8l-7.72 7.73a.75.75 0 0 1-.98.07l-.08-.07-2.97-2.97-5.47 5.47a.75.75 0 0 1-1.13-.98l.07-.08 6-6a.75.75 0 0 1 .98-.07l.08.07 2.97 2.97L19.44 7h-5.7a.75.75 0 0 1-.73-.65l-.01-.1c0-.38.28-.7.65-.74z"], "CheckmarkStarburst24Regular": ["M6.35 3.75a2.75 2.75 0 0 1 3.81-1.58l1.29.63c.35.17.75.17 1.1 0l1.28-.63a2.75 2.75 0 0 1 3.69 1.25l.07.16.06.17.46 1.36c.13.36.42.65.78.78l1.36.46a2.75 2.75 0 0 1 1.58 3.82l-.63 1.28c-.17.35-.17.75 0 1.1l.63 1.29a2.75 2.75 0 0 1-1.58 3.81l-1.36.46c-.36.13-.65.42-.78.78l-.46 1.36a2.75 2.75 0 0 1-3.82 1.58l-1.28-.63a1.3 1.3 0 0 0-1.1 0l-1.28.63a2.75 2.75 0 0 1-3.82-1.58l-.46-1.36a1.3 1.3 0 0 0-.78-.78l-1.36-.46a2.75 2.75 0 0 1-1.58-3.81l.63-1.29c.17-.35.17-.75 0-1.1l-.63-1.28a2.75 2.75 0 0 1 1.58-3.82l1.36-.46c.36-.13.65-.42.78-.78zm9.76.22a1.25 1.25 0 0 0-1.61-.45l-1.29.63c-.76.37-1.66.37-2.42 0L9.5 3.52a1.26 1.26 0 0 0-1.73.72L7.3 5.59c-.28.8-.91 1.44-1.72 1.72l-1.35.46q-.08.02-.16.06c-.61.3-.87 1.05-.56 1.67l.63 1.29c.37.76.37 1.66 0 2.42l-.63 1.29a1.25 1.25 0 0 0 .72 1.73l1.35.46c.8.28 1.44.91 1.72 1.72l.46 1.35q.02.08.06.15c.3.62 1.05.88 1.67.57l1.29-.63a2.8 2.8 0 0 1 2.42 0l1.29.63.15.07c.65.22 1.36-.13 1.58-.79l.46-1.35c.28-.8.91-1.44 1.72-1.72l1.35-.46q.08-.02.15-.06c.62-.3.88-1.05.57-1.67l-.63-1.29a2.8 2.8 0 0 1 0-2.42l.63-1.29.07-.15a1.25 1.25 0 0 0-.79-1.58l-1.35-.46a2.8 2.8 0 0 1-1.72-1.72l-.46-1.35-.03-.08-.03-.08zm-.89 5a.75.75 0 1 1 1.06 1.06l-5 5c-.3.3-.77.3-1.06 0l-2.5-2.5a.75.75 0 0 1 1.06-1.06l1.97 1.97z"], "VideoClip24Regular": ["M2 6.25C2 4.45 3.46 3 5.25 3h13.5C20.55 3 22 4.46 22 6.25v11.5c0 1.8-1.46 3.25-3.25 3.25H5.25A3.25 3.25 0 0 1 2 17.75zM5.25 4.5c-.97 0-1.75.78-1.75 1.75v11.5c0 .97.78 1.75 1.75 1.75h13.5c.97 0 1.75-.78 1.75-1.75V6.25c0-.97-.78-1.75-1.75-1.75zM9 9.25v5.5a1 1 0 0 0 1.48.88l5-2.75a1 1 0 0 0 0-1.76l-5-2.75A1 1 0 0 0 9 9.25"], "Sparkle24Regular": ["M8.67 15.73q.37.27.83.27a1.4 1.4 0 0 0 1.33-.88l.61-1.86a2.9 2.9 0 0 1 1.82-1.81l1.78-.58a1.44 1.44 0 0 0-.06-2.74l-1.75-.57a2.9 2.9 0 0 1-1.82-1.82l-.58-1.78a1.45 1.45 0 0 0-2.73.02l-.59 1.8a2.9 2.9 0 0 1-1.77 1.78l-1.77.57a1.44 1.44 0 0 0 .01 2.73l1.76.57a2.9 2.9 0 0 1 1.82 1.83l.58 1.77q.15.44.53.7m-.38-4.25-.36-.4A4.4 4.4 0 0 0 6.21 10l-1.6-.5 1.61-.53A4.4 4.4 0 0 0 8.95 6.2l.52-1.58.51 1.59a4.4 4.4 0 0 0 2.79 2.77l1.61.52-1.58.52a4.4 4.4 0 0 0-2.78 2.77l-.51 1.59-.52-1.59q-.25-.71-.7-1.3m8.04 9.3q-.29-.2-.4-.55l-.34-1a1.3 1.3 0 0 0-.82-.83l-.99-.32A1.15 1.15 0 0 1 13 17a1.1 1.1 0 0 1 .77-1.08l1-.33a1.3 1.3 0 0 0 .8-.82l.33-.99a1.14 1.14 0 0 1 2.16-.02l.33 1.01a1.3 1.3 0 0 0 .82.82l.99.32a1.14 1.14 0 0 1 .04 2.17l-1.01.33a1.3 1.3 0 0 0-.82.82l-.32.99a1.14 1.14 0 0 1-1.76.56M15.3 17a2.8 2.8 0 0 1 1.7 1.7 2.8 2.8 0 0 1 1.7-1.7 2.8 2.8 0 0 1-1.72-1.7A2.8 2.8 0 0 1 15.3 17"], "Edit24Regular": ["M20.95 3.05a3.6 3.6 0 0 0-5.06 0L3.94 15c-.4.4-.7.92-.82 1.48l-1.1 4.6a.75.75 0 0 0 .9.9l4.6-1.1A3 3 0 0 0 9 20.07L20.95 8.11a3.6 3.6 0 0 0 0-5.06m-4 1.06a2.08 2.08 0 1 1 2.94 2.94l-.89.89L16.06 5zM15 6.06 17.94 9l-10 10a1.6 1.6 0 0 1-.76.43l-3.42.8.82-3.4q.1-.45.42-.77z"], "Filmstrip24Regular": ["M2 7.25C2 5.45 3.46 4 5.25 4h13.5C20.55 4 22 5.46 22 7.25v9.5c0 1.8-1.46 3.25-3.25 3.25H5.25A3.25 3.25 0 0 1 2 16.75zM5.25 5.5c-.97 0-1.75.78-1.75 1.75v9.5c0 .97.78 1.75 1.75 1.75h13.5c.97 0 1.75-.78 1.75-1.75v-9.5c0-.97-.78-1.75-1.75-1.75zM17.5 7.75a.75.75 0 0 1 1.5 0v.5a.75.75 0 0 1-1.5 0zm.75 7.25a.75.75 0 0 0-.75.75v.5a.75.75 0 0 0 1.5 0v-.5a.75.75 0 0 0-.75-.75m-.75-3.25a.75.75 0 0 1 1.5 0v.5a.75.75 0 0 1-1.5 0zM5.75 7a.75.75 0 0 0-.75.75v.5a.75.75 0 0 0 1.5 0v-.5A.75.75 0 0 0 5.75 7M5 15.75a.75.75 0 0 1 1.5 0v.5a.75.75 0 0 1-1.5 0zM5.75 11a.75.75 0 0 0-.75.75v.5a.75.75 0 0 0 1.5 0v-.5a.75.75 0 0 0-.75-.75"], "Alert24Regular": ["M12 2a7.5 7.5 0 0 1 7.5 7.25v4.35l1.38 3.15a1.25 1.25 0 0 1-1.15 1.75H15a3 3 0 0 1-6 .18v-.18H4.27a1.25 1.25 0 0 1-1.14-1.75L4.5 13.6V9.5C4.5 5.35 7.85 2 12 2m1.5 16.5h-3a1.5 1.5 0 0 0 3 .15zM12 3.5c-3.32 0-6 2.67-6 6v4.4L4.66 17h14.7L18 13.9V9.29a6 6 0 0 0-6-5.78"], "ZoomIn24Regular": ["M10 6.5c.41 0 .75.34.75.75v2h2a.75.75 0 0 1 0 1.5h-2v2a.75.75 0 0 1-1.5 0v-2h-2a.75.75 0 0 1 0-1.5h2v-2c0-.41.34-.75.75-.75M10 2a8 8 0 0 1 6.16 13.1l4.62 4.62a.75.75 0 0 1-1.06 1.06l-4.62-4.62A8 8 0 1 1 10 2m0 1.5a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13"], "ZoomOut24Regular": ["M12.75 9.25a.75.75 0 0 1 0 1.5h-5.5a.75.75 0 0 1 0-1.5zM10 2a8 8 0 0 1 6.16 13.1l4.62 4.62a.75.75 0 0 1-1.06 1.06l-4.62-4.62A8 8 0 1 1 10 2m0 1.5a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13"], "ArrowReset24Regular": ["M6.78 2.72c.3.3.3.77 0 1.06L4.56 6h8.69a7.75 7.75 0 1 1-7.75 7.75.75.75 0 0 1 1.5 0 6.25 6.25 0 1 0 6.25-6.25H4.56l2.22 2.22a.75.75 0 1 1-1.06 1.06l-3.5-3.5a.75.75 0 0 1 0-1.06l3.5-3.5c.3-.3.77-.3 1.06 0"], "ArrowLeft24Regular": ["M10.73 19.8a.75.75 0 0 0 1.04-1.1l-6.25-5.95h14.73a.75.75 0 0 0 0-1.5H5.52l6.25-5.95a.75.75 0 0 0-1.04-1.1l-7.42 7.08a1 1 0 0 0 0 1.44z"], "ArrowUp16Regular": ["M7.5 13.5a.5.5 0 0 0 1 0V3.8l3.63 4.03a.5.5 0 0 0 .74-.66l-4.5-5a.5.5 0 0 0-.74 0l-4.5 5a.5.5 0 0 0 .74.66L7.5 3.8z"], "ArrowDown16Regular": ["M8.5 2.5a.5.5 0 1 0-1 0v9.7L3.87 8.17a.5.5 0 1 0-.74.66l4.5 5a.5.5 0 0 0 .74 0l4.5-5a.5.5 0 0 0-.74-.66L8.5 12.2z"], "Dismiss16Regular": ["m2.59 2.72.06-.07a.5.5 0 0 1 .63-.06l.07.06L8 7.29l4.65-4.64a.5.5 0 0 1 .7.7L8.71 8l4.64 4.65c.18.17.2.44.06.63l-.06.07a.5.5 0 0 1-.63.06l-.07-.06L8 8.71l-4.65 4.64a.5.5 0 0 1-.7-.7L7.29 8 2.65 3.35a.5.5 0 0 1-.06-.63l.06-.07z"], "Live24Regular": ["M5.99 4.93c.3.3.3.77 0 1.06a8.5 8.5 0 0 0 0 12.02.75.75 0 0 1-1.06 1.06 10 10 0 0 1 0-14.14c.3-.3.77-.3 1.06 0m13.08 0a10 10 0 0 1 0 14.14.75.75 0 0 1-1.06-1.06 8.5 8.5 0 0 0 0-12.02.75.75 0 1 1 1.06-1.06M8.82 7.76c.3.29.3.76 0 1.06a4.5 4.5 0 0 0 0 6.36.75.75 0 0 1-1.06 1.06 6 6 0 0 1 0-8.48c.29-.3.77-.3 1.06 0m7.42 0a6 6 0 0 1 0 8.48.75.75 0 1 1-1.06-1.06 4.5 4.5 0 0 0 0-6.36.75.75 0 0 1 1.06-1.06M12 10.5a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3"], "People24Regular": ["M5.5 8a2.5 2.5 0 1 1 5 0 2.5 2.5 0 0 1-5 0M8 4a4 4 0 1 0 0 8 4 4 0 0 0 0-8m7.5 5a1.5 1.5 0 1 1 3 0 1.5 1.5 0 0 1-3 0M17 6a3 3 0 1 0 0 6 3 3 0 0 0 0-6m-2.75 13.04q1.04.44 2.75.46c2.28 0 3.59-.7 4.3-1.56a3 3 0 0 0 .7-1.73v-.03c0-1.2-.97-2.18-2.18-2.18H14.1q.6.63.81 1.5h4.91a.7.7 0 0 1 .68.7l-.04.18q-.05.25-.32.6C19.8 17.42 18.97 18 17 18c-.98 0-1.67-.15-2.17-.34q-.14.62-.58 1.38M4.25 14C3.01 14 2 15 2 16.25v.28l.01.2q.02.21.1.53c.09.42.29.98.68 1.55C3.61 19.97 5.17 21 8 21s4.39-1.03 5.2-2.2a4.5 4.5 0 0 0 .8-2.27v-.28c0-1.24-1-2.25-2.25-2.25zm-.75 2.5v-.25c0-.41.34-.75.75-.75h7.5c.41 0 .75.34.75.75v.34l-.06.33c-.07.28-.2.65-.46 1.02-.5.71-1.56 1.56-3.98 1.56s-3.49-.85-3.98-1.56a3 3 0 0 1-.52-1.43"]};
  const icon = (n) => '<svg viewBox="0 0 ' + (n.endsWith('16Regular') ? '16 16' : '24 24') + '" aria-hidden="true">' + ICONS[n].map((d) => '<path d="' + d + '"/>').join('') + '</svg>';
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
  const byId = (id) => document.getElementById(id);
  const R = window.MUNDOFIT_REAL;
  const FLAGS = { BR: '<rect width="30" height="20" fill="#009C3B"/><path d="M15 2.5 27 10 15 17.5 3 10Z" fill="#FFDF00"/><circle cx="15" cy="10" r="4.6" fill="#002776"/><path d="M10.6 9.2c3-.9 6.2-.6 8.8 1" stroke="#fff" stroke-width=".8" fill="none"/>' };
  const flag = (code) => '<svg class="vg-flag" viewBox="0 0 30 20" aria-hidden="true">' + FLAGS[code] + '</svg>';

  const brl = (v) => (v < 0 ? 'BRL -' : 'BRL ') + Math.abs(v).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const brlShort = (v) => 'BRL ' + (Math.abs(v) >= 1000 ? (v / 1000).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + ' mil' : Math.round(v).toLocaleString('pt-BR'));
  const int = (v) => Math.round(v).toLocaleString('pt-BR');
  const pct = (v, d = 1) => v.toLocaleString('pt-BR', { minimumFractionDigits: d, maximumFractionDigits: d }) + '%';
  const x2 = (v) => v.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + 'x';

  /* Períodos com dado real. Ontem vem do relatório diário; Q4 até hoje é igual a outubro, porque o Q4 começou em 01/10. */
  const H = R.historico || R.diario;
  const D = R.diario;
  const monthDays = H.filter(d => d.data.endsWith('/10'));
  const roiDay = d => ({...d, roi: d.gastos ? d.liquido / (d.gastos + (d.despesas || 0)) : 0});
  const day = (i) => ({ vendas: D[i].vendas, liquido: D[i].liquido, gastos: D[i].gastos, lucro: D[i].lucro, roas: D[i].roas, roi: roiDay(D[i]).roi, bruto: null, label: D[i].data });
  const PERIODS = {
    today: ['Hoje', 'CalendarToday24Regular', () => ({ ...R.periodos.hoje, label: '28/10, dia parcial', sel: ['28/10'], days: [D[D.length - 1]] })], /* dia parcial: sem comparação com o dia anterior inteiro */
    yesterday: ['Ontem', 'History24Regular', () => ({ ...day(D.length - 2), prev: day(D.length - 3), prevLabel: 'vs 26/10', sel: ['27/10'], days: [D[D.length - 2]] })],
    d7: ['7 dias', 'DataBarVertical24Regular', () => ({ ...R.periodos.sete_dias, label: D[0].data + ' a ' + D[D.length - 1].data, sel: D.map((d) => d.data), days: D })],
    month: ['Este mês', 'CalendarLtr24Regular', () => ({ ...R.periodos.outubro, label: '01/10 a 28/10', ref: R.periodos.setembro, sel: D.map((d) => d.data), days: monthDays, sel: monthDays.map(d => d.data) })],
    q4: ['Q4 até hoje', 'Trophy24Regular', () => ({ ...R.periodos.outubro, label: '01/10 a 28/10', ref: R.periodos.setembro, sel: D.map((d) => d.data), days: monthDays, sel: monthDays.map(d => d.data) })]
  };
  const iso = (d) => '2026-' + d.data.slice(3) + '-' + d.data.slice(0, 2);
  /* período personalizado: só dentro da série diária real, de 22/10 a 28/10 */
  function custom() {
    const days = H.filter((d) => iso(d) >= st.from && iso(d) <= st.to);
    const sum = (k) => days.reduce((a, d) => a + d[k], 0);
    const gastos = sum('gastos'), liquido = sum('liquido'), vendas = sum('vendas'), lucro = sum('lucro');
    return { vendas, liquido, gastos, lucro, bruto: null, roi: gastos ? liquido / gastos : 0, roas: gastos ? days.reduce((a, d) => a + d.roas * d.gastos, 0) / gastos : 0, cpa: vendas ? gastos / vendas : 0, margem: liquido ? (lucro / liquido) * 100 : 0,
      label: days.length ? days[0].data + (days.length > 1 ? ' a ' + days[days.length - 1].data : '') : 'Sem dias no intervalo', sel: days.map((d) => d.data), days };
  }
  const MIN_DAY = '2026-09-01', MAX_DAY = '2026-10-28';
  const RANGES = { today: ['2026-10-28', '2026-10-28'], yesterday: ['2026-10-27', '2026-10-27'], d7: ['2026-10-22', MAX_DAY], month: ['2026-10-01', MAX_DAY], q4: ['2026-10-01', MAX_DAY] };
  const st = { period: 'd7', from: '2026-10-22', to: MAX_DAY, mapView: 'world', zoom: 2.2, center: null };
  const cur = () => (st.period === 'custom' ? custom() : PERIODS[st.period][2]());

  function delta(now, prev, invert) {
    if (prev === undefined || prev === null || !prev) return '';
    const v = now / prev - 1, good = invert ? v <= 0 : v >= 0;
    return '<span class="vg-delta ' + (good ? 'good' : 'bad') + '">' + icon(v >= 0 ? 'ArrowUp16Regular' : 'ArrowDown16Regular') + pct(Math.abs(v * 100), 0) + '</span>';
  }
  function spark(values, cls) {
    if (!values.length) return '<p class="vg-spark">Série ainda não disponível</p>';
    if (values.length === 1) return '<svg class="vg-spark ' + cls + '" viewBox="0 0 300 48" role="img" aria-label="Um total diário disponível, sem série intradiária"><circle cx="150" cy="24" r="5" fill="currentColor"/></svg><small>Um total diário, sem curva por hora</small>';
    const max = Math.max(...values), min = Math.min(...values);
    const pts = values.map((v, i) => [(i / (values.length - 1)) * 300, 44 - ((v - min) / (max - min || 1)) * 36]);
    const line = 'M' + pts.map((p) => p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join('L');
    return '<svg class="vg-spark ' + cls + '" viewBox="0 0 300 48" preserveAspectRatio="none" aria-hidden="true"><path d="' + line + 'L300 48L0 48Z" class="area"/><path d="' + line + '" class="line"/></svg>';
  }
  const kpi = (ic, tone, label, value, note, sp) => '<article class="panel vg-kpi"><div class="vg-kpi-head"><span class="vg-ic ' + tone + '">' + icon(ic) + '</span>' + label + '</div><strong class="vg-kpi-value num">' + value + '</strong><div class="vg-kpi-note">' + (note || '') + '</div>' + (sp || '') + '</article>';

  /* criativos de 7 dias: só existem para o período de 7 dias */
  const VALID = (a) => a.vendas >= 10 && a.roas >= 1.5; /* regra das planilhas da Thaix, até Pedro Ivo Torres definir */
  function renderKpis() {
    const p = cur(), s = (k) => (p.days || []).map((d) => k === 'roi' ? roiDay(d).roi : d[k]);
    const cmp = (k, inv) => (p.prev ? delta(p[k], p.prev[k], inv) + ' ' + p.prevLabel : p.ref ? 'Setembro: ' + (k === 'vendas' ? int(p.ref[k]) : k === 'roas' ? x2(p.ref[k]) : brl(p.ref[k])) : '');
    const dailyNote = 'Relatório diário conferido · '+p.label;
    byId('vg-kpis').innerHTML = [
      kpi('Cart24Regular', 'blue', 'Vendas aprovadas', int(p.vendas), dailyNote, spark(s('vendas'), 'blue')),
      kpi('Money24Regular', 'green', 'Faturamento líquido', brl(p.liquido), [p.bruto ? 'Bruto: ' + brl(p.bruto) : '', cmp('liquido')].filter(Boolean).join(' · '), spark(s('liquido'), 'green')),
      kpi('Megaphone24Regular', 'orange', 'Gastos com anúncios', brl(p.gastos), cmp('gastos', true), spark(s('gastos'), 'orange')),
      kpi('Wallet24Regular', 'gold', 'Lucro', '<span class="' + (p.lucro >= 0 ? 'pos' : 'neg') + '">' + brl(p.lucro) + '</span>', cmp('lucro'), spark(s('lucro'), 'gold')),
      kpi('ArrowTrending24Regular', 'purple', 'ROI líquido', x2(p.roi ?? (p.gastos ? p.liquido / p.gastos : 0)), 'Receita líquida ÷ gastos e despesas', spark(s('roi'), 'purple')),
      kpi('CheckmarkStarburst24Regular', 'gold', 'Validados na última planilha', int(R.semanas.at(-1).validados.length), '19/10 a 25/10 · indicador semanal independente do filtro'),
      kpi('People24Regular', 'pink', 'CPA', p.cpa ? brl(p.cpa) : brl(p.gastos / p.vendas), p.margem !== undefined ? 'Margem: ' + pct(p.margem) : ''),
      kpi('Sparkle24Regular', 'green', 'Criativos na amostra', int(R.criativos.filter((a) => a.vendas > 0).length), '22/10 a 28/10 · parcial, extraído às 19:05')
    ].join('');
  }

  /* destaque por função: 7 dias, soma dos criativos com vínculo exato no ClickUp */
  function people(field) {
    const m = {};
    R.criativos.filter((a) => a[field]).forEach((a) => { const k = a[field]; m[k] = m[k] || { name: k, vendas: 0, lucro: 0, n: 0 }; m[k].vendas += a.vendas; m[k].lucro += a.lucro; m[k].n++; });
    return Object.values(m).sort((x, y) => y.lucro - x.lucro);
  }
  function renderRoles() {
    const p = cur();
    byId('vg-roles').innerHTML = '<article class="panel vg-role"><h2>Copywriter</h2><p>Tiago Neiva</p><strong class="num">' + brl(p.lucro) + '</strong><p>Crédito de autoria da operação no período selecionado, conforme regra da equipe. Não é comissão.</p><a href="#equipe">Conferir atribuição</a></article><article class="panel vg-role"><h2>Editores ADS</h2><p>Retorno individual a conciliar.</p><p>Receita sem vínculo e recortes incompletos não entram como prejuízo pessoal.</p><a href="#equipe">Conferir responsáveis</a></article>';
  }

  function barChart(days, series, opts) {
    const W = 600, H = 260, L = opts.left || 48, B = 30, T = 12;
    const vals = days.flatMap((d) => series.map((s) => s.get(d)));
    const max = Math.max(...vals) * 1.1 || 1;
    const slot = (W - L) / days.length, bw = Math.min(28, (slot * 0.7) / series.length);
    const y = (v) => H - B - ((H - T - B) * Math.max(v, 0)) / max;
    const grid = [0, 0.25, 0.5, 0.75, 1].map((t) => '<line class="vg-grid" x1="' + L + '" x2="' + W + '" y1="' + y(max * t).toFixed(1) + '" y2="' + y(max * t).toFixed(1) + '"/><text class="geo-axis" x="' + (L - 8) + '" y="' + (y(max * t) + 4).toFixed(1) + '" text-anchor="end">' + opts.tick(max * t) + '</text>').join('');
    const bars = days.map((d, i) => { const cx = L + slot * i + slot / 2; return series.map((s, j) => { const v = s.get(d); const x = cx - (bw * series.length) / 2 + j * bw; return '<rect class="vg-bar ' + s.cls + (opts.sel.includes(d.data) ? '' : ' off') + '" x="' + x.toFixed(1) + '" y="' + y(v).toFixed(1) + '" width="' + (bw - 2).toFixed(1) + '" height="' + (H - B - y(v)).toFixed(1) + '" rx="3"><title>' + d.data + ': ' + s.fmt(v) + '</title></rect>'; }).join('') + '<text class="geo-axis" x="' + cx.toFixed(1) + '" y="' + (H - 8) + '" text-anchor="middle">' + d.data + '</text>'; }).join('');
    return '<svg class="vg-chart" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + opts.label + '">' + grid + bars + '</svg>';
  }
  function renderCharts() {
    const p = cur();
    byId('vg-daily').innerHTML = barChart(p.days || [], [{ cls: 'blue', get: (d) => d.vendas, fmt: (v) => int(v) + ' vendas' }], { tick: int, sel: p.sel, label: 'Vendas aprovadas por dia, no período selecionado.' });
    byId('vg-money').innerHTML = barChart(p.days || [], [{ cls: 'blue', get: (d) => d.liquido, fmt: brl }, { cls: 'orange', get: (d) => d.gastos, fmt: brl }], { tick: brlShort, left: 92, sel: p.sel, label: 'Faturamento líquido e gastos por dia, no período selecionado.' });
    const f = p.funil;
    if (!f) { byId('vg-funnel').innerHTML = '<p class="geo-empty">A Utmify não informa o funil deste período. Escolha hoje, 7 dias ou o mês.</p>'; return; }
    const steps = [['Cliques', f.cliques], ['Visitas à página', f.vis_pagina], ['Checkouts iniciados', f.ics], ['Vendas iniciadas', f.vendas_iniciadas], ['Vendas aprovadas', f.vendas_aprovadas]];
    byId('vg-funnel').innerHTML = '<p class="muted">Extração de 28/10 às 19:05. O financeiro tem atualização posterior.</p><ol class="vg-funnel">' + steps.map(([l, v]) => '<li><div class="geo-row"><span>' + l + '</span><span class="num"><b>' + int(v) + '</b> ' + pct((v / f.cliques) * 100) + '</span></div><div class="geo-track"><i style="width:' + ((v / f.cliques) * 100).toFixed(1) + '%"></i></div></li>').join('') + '</ol>' +
      (p.aprovacao ? '<h3 class="vg-sub-h">Aprovação por pagamento</h3><dl class="vg-pay">' + [['Pix', p.aprovacao.pix], ['Cartão', p.aprovacao.cartao], ['Boleto', p.aprovacao.boleto]].filter((x) => x[1] != null).map(([l, v]) => '<div><dt>' + l + '</dt><dd class="num">' + pct(v) + '</dd></div>').join('') + '</dl>' : '');
  }

  /* origem das vendas: fontes da Utmify; vendas sem UTM não entram nas contas de anúncio */
  const SOURCE = { MetaAds: 'Meta Ads', 'N/A': 'Sem UTM', 'LL-backredirect': 'Lastlink backredirect', SMSFunnel: 'SMS Funnel', ig: 'Instagram', organic: 'Orgânico' };
  function renderSources() {
    const p = cur();
    byId('vg-sources').innerHTML = p.fontes ? '<li class="muted">Extração de 28/10 às 19:05</li>' + p.fontes.map((s) => '<li><div class="geo-row"><span>' + esc(SOURCE[s.fonte] || s.fonte) + '</span><span class="num"><b>' + int(s.vendas) + '</b> ' + pct(s.share_pct) + '</span></div><div class="geo-track' + (s.fonte === 'N/A' ? ' warn' : '') + '"><i style="width:' + s.share_pct + '%"></i></div></li>').join('') : '<li class="geo-empty">A Utmify não informa a origem deste período. Escolha hoje, 7 dias ou o mês.</li>';
  }

  /* mapa: o painel Principal da Utmify vende no Brasil; LATAM é outro painel, fora desta extração */
  const MAP = window.MUNDOFIT_MAPA;
  function renderMap() {
    const p = cur(), svg = byId('vg-map');
    if (st.mapView === 'brazil') {
      svg.setAttribute('viewBox', '0 0 600 600');
      svg.setAttribute('aria-label', 'Mapa do Brasil por estado. Sem dados por estado.');
      svg.innerHTML = MAP.brazil.map((s) => '<path class="vg-uf empty" d="' + s.d + '"><title>' + esc(s.name) + ': sem dados</title></path>').join('');
      byId('vg-map-title').textContent = 'Brasil por estado';
      byId('vg-map-back').hidden = false;
      byId('vg-list').innerHTML = '<li class="geo-empty">A extração da Utmify não traz vendas por estado.</li>';
      return;
    }
    const w = 1000 / st.zoom, h = 520 / st.zoom, c = st.center || [500, 260];
    svg.setAttribute('viewBox', [Math.min(Math.max(c[0] - w / 2, 0), 1000 - w), Math.min(Math.max(c[1] - h / 2, 0), 520 - h), w, h].map((v) => v.toFixed(1)).join(' '));
    svg.setAttribute('aria-label', 'Mapa-múndi. Vendas do painel Principal: Brasil.');
    const fit = () => { const vw = 1000 / st.zoom, vh = 520 / st.zoom, cc = st.center; svg.setAttribute('viewBox', [Math.min(Math.max(cc[0] - vw / 2, 0), 1000 - vw), Math.min(Math.max(cc[1] - vh / 2, 0), 520 - vh), vw, vh].map((v) => v.toFixed(1)).join(' ')); };
    svg.innerHTML = MAP.world.map((m) => (m.id === '076'
      ? '<path class="vg-country has flagged" data-id="076" d="' + m.d + '" style="fill:url(#flag-BR)" tabindex="0" role="button" aria-label="Brasil: ' + int(p.vendas) + ' vendas. Abrir estados."><title>Brasil: ' + int(p.vendas) + ' vendas</title></path>'
      : '<path class="vg-country" d="' + m.d + '"><title>' + esc(m.name) + '</title></path>')).join('') +
      '<defs><pattern id="flag-BR" patternContentUnits="objectBoundingBox" width="1" height="1"><svg width="1" height="1" viewBox="0 0 30 20" preserveAspectRatio="xMidYMid slice">' + FLAGS.BR + '</svg></pattern></defs><g id="vg-map-labels"></g>';
    const br = svg.querySelector('[data-id="076"]'), b = br.getBBox();
    if (!st.center) st.center = [b.x + b.width / 2, b.y + b.height / 2];
    fit();
    svg.querySelector('#vg-map-labels').innerHTML = '<g class="vg-pin" transform="translate(' + (b.x + b.width / 2).toFixed(1) + ' ' + (b.y + b.height / 2).toFixed(1) + ') scale(' + (1 / st.zoom).toFixed(3) + ')"><rect x="-40" y="-12" width="80" height="24" rx="6"/><svg class="vg-flag-svg" x="-34" y="-6" width="18" height="12" viewBox="0 0 30 20">' + FLAGS.BR + '</svg><text text-anchor="middle" x="10" y="4">' + int(p.vendas) + '</text></g>';
    const open = () => { st.mapView = 'brazil'; renderMap(); };
    br.addEventListener('click', open);
    br.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); } });
    byId('vg-map-title').textContent = 'Por país';
    byId('vg-map-back').hidden = true;
    byId('vg-list').innerHTML = '<li><div class="geo-row"><span>' + flag('BR') + 'Brasil</span><span class="num"><b>' + int(p.vendas) + '</b> 100%</span></div><div class="geo-track"><i style="width:100%"></i></div><small class="vg-row-note">' + brl(p.liquido) + ' líquidos · ROAS ' + x2(p.roas) + '</small></li>';
  }

  function renderFilters() {
    document.querySelectorAll('#vg-periods .vg-period').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.period === st.period)));
    const RANGE = st.period === 'custom' ? [st.from, st.to] : RANGES[st.period];
    byId('vg-from').value = RANGE[0]; byId('vg-to').value = RANGE[1];
    byId('vg-range').innerHTML = icon('CalendarLtr24Regular') + cur().label;
    const o = R.periodos.outubro, proj = (o.liquido / 28) * 31;
    byId('hd-goal-text').innerHTML = 'Outubro: <b class="num">' + brlShort(o.liquido) + '</b> · projeção ' + brlShort(proj);
    byId('hd-goal-bar').style.width = ((28 / 31) * 100).toFixed(1) + '%';
    byId('hd-goal-pct').textContent = 'dia 28 de 31';
  }
  function render() { renderFilters(); renderKpis(); renderRoles(); renderCharts(); renderSources(); renderMap(); }

  byId('vg-periods').innerHTML = Object.entries(PERIODS).map(([k, [label, ic]]) => '<button class="vg-period" type="button" data-period="' + k + '">' + icon(ic) + label + '</button>').join('');
  byId('hd-live').textContent = 'Financeiro: relatório de 28/10 · demais fontes: 19:05';
  byId('vg-zoom-in').innerHTML = icon('ZoomIn24Regular'); byId('vg-zoom-out').innerHTML = icon('ZoomOut24Regular'); byId('vg-zoom-reset').innerHTML = icon('ArrowReset24Regular');
  byId('vg-map-back').insertAdjacentHTML('afterbegin', icon('ArrowLeft24Regular'));
  byId('vg-clear').insertAdjacentHTML('afterbegin', icon('ArrowReset24Regular'));
  document.querySelectorAll('#vg-periods .vg-period').forEach((b) => b.addEventListener('click', () => { st.period = b.dataset.period; render(); }));
  ['vg-from', 'vg-to'].forEach((id) => { byId(id).min = MIN_DAY; byId(id).max = MAX_DAY; byId(id).addEventListener('change', () => {
    let a = byId('vg-from').value || MIN_DAY, b = byId('vg-to').value || MAX_DAY;
    a = a < MIN_DAY ? MIN_DAY : a > MAX_DAY ? MAX_DAY : a; b = b < MIN_DAY ? MIN_DAY : b > MAX_DAY ? MAX_DAY : b;
    if (a > b) [a, b] = [b, a];
    Object.assign(st, { period: 'custom', from: a, to: b }); render();
  }); });
  byId('vg-clear').addEventListener('click', () => { Object.assign(st, { period: 'd7', from: '2026-10-22', to: MAX_DAY, mapView: 'world', zoom: 2.2, center: null }); render(); });
  byId('vg-zoom-in').addEventListener('click', () => { st.zoom = Math.min(st.zoom * 1.5, 8); renderMap(); });
  byId('vg-zoom-out').addEventListener('click', () => { st.zoom = Math.max(st.zoom / 1.5, 1); renderMap(); });
  byId('vg-zoom-reset').addEventListener('click', () => { st.zoom = 2.2; st.center = null; renderMap(); });
  byId('vg-map-back').addEventListener('click', () => { Object.assign(st, { mapView: 'world', zoom: 2.2, center: null }); renderMap(); });
  render();
})();
