/* Metas do Mundo FIT com dados reais da Utmify (extração de 28/10/2026 19:05).
   Projeção linear: faturamento líquido de outubro / 28 dias x 31 dias. Metas Base, Alvo e Disney: a definir por Pedro Ivo Torres.
   Até lá, a referência é setembro, o último mês fechado. Ícones: Fluent 2 Regular. */
(() => {
  const ICONS = {"Target24Regular": ["M12 14a2 2 0 1 0 0-4 2 2 0 0 0 0 4m-6-2a6 6 0 1 1 12 0 6 6 0 0 1-12 0m6-4.5a4.5 4.5 0 1 0 0 9 4.5 4.5 0 0 0 0-9M2 12a10 10 0 1 1 20 0 10 10 0 0 1-20 0m10-8.5a8.5 8.5 0 1 0 0 17 8.5 8.5 0 0 0 0-17"], "Gift24Regular": ["M14.5 2a3.25 3.25 0 0 1 2.74 5h2.51c.69 0 1.25.56 1.25 1.25v3.5c0 .6-.43 1.1-1 1.22v5.78a3.25 3.25 0 0 1-3.07 3.24l-.18.01h-9.5a3.25 3.25 0 0 1-3.24-3.07L4 18.75v-5.77c-.57-.12-1-.63-1-1.23v-3.5C3 7.56 3.56 7 4.25 7h2.51q-.5-.76-.51-1.75A3.25 3.25 0 0 1 12 3.17C12.6 2.46 13.5 2 14.5 2m-3.25 11H5.5v5.75c0 .92.7 1.67 1.6 1.74l.15.01h4zm7.25 0h-5.75v7.5h4c.92 0 1.67-.7 1.74-1.6l.01-.15zm-7.25-4.5H4.5v3h6.75zm8.25 3v-3h-6.75v3zm-5-8c-.97 0-1.75.78-1.75 1.75V7h1.89a1.75 1.75 0 0 0-.14-3.5m-5 0A1.75 1.75 0 0 0 9.36 7h1.89V5.1c-.08-.9-.83-1.61-1.75-1.61"], "Info16Regular": ["M8.5 7.5a.5.5 0 1 0-1 0v3a.5.5 0 0 0 1 0zm.25-2a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0M8 1a7 7 0 1 0 0 14A7 7 0 0 0 8 1M2 8a6 6 0 1 1 12 0A6 6 0 0 1 2 8"], "CalendarLtr24Regular": ["M17.75 3C19.55 3 21 4.46 21 6.25v11.5c0 1.8-1.46 3.25-3.25 3.25H6.25A3.25 3.25 0 0 1 3 17.75V6.25C3 4.45 4.46 3 6.25 3zm1.75 5.5h-15v9.25c0 .97.78 1.75 1.75 1.75h11.5c.97 0 1.75-.78 1.75-1.75zm-11.75 6a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5m4.25 0a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5m-4.25-4a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5m4.25 0a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5m4.25 0a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5m1.5-6H6.25c-.97 0-1.75.78-1.75 1.75V7h15v-.75c0-.97-.78-1.75-1.75-1.75"]};
  const icon = (n) => '<svg viewBox="0 0 24 24" aria-hidden="true">' + ICONS[n].map((d) => '<path d="' + d + '"/>').join('') + '</svg>';
  const byId = (id) => document.getElementById(id);
  const R = window.MUNDOFIT_REAL;
  const O = R.periodos.outubro, S = R.periodos.setembro, D = R.diario;
  const PASSED = 28, DAYS = 31, left = DAYS - PASSED;
  const pace = O.liquido / PASSED, forecast = pace * DAYS;
  const need = Math.max(S.liquido - O.liquido, 0) / left;
  const brl = (v) => (v < 0 ? 'BRL -' : 'BRL ') + Math.abs(v).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const pc = (v, d = 1) => (v * 100).toLocaleString('pt-BR', { minimumFractionDigits: d, maximumFractionDigits: d }) + '%';
  const int = (v) => Math.round(v).toLocaleString('pt-BR');

  const real = O.liquido / S.liquido;
  const status = forecast >= S.liquido ? ['Acima de setembro', 'ok'] : forecast >= S.liquido * 0.95 ? ['Quase lá', 'near'] : ['Abaixo de setembro', 'warn'];
  byId('mg-cards').innerHTML =
    '<article class="panel mg-card mg-base" aria-labelledby="mg-out"><header class="mg-head"><div><h2 id="mg-out">Outubro contra setembro</h2><p class="mg-target num">Setembro: ' + brl(S.liquido) + ' líquidos</p></div><span class="mg-status ' + status[1] + '">' + status[0] + '</span></header>' +
    '<div class="mg-gauge" role="img" aria-label="Outubro já tem ' + pc(real) + ' do faturamento líquido de setembro"><svg viewBox="0 0 200 200" aria-hidden="true"><circle class="mg-track" cx="100" cy="100" r="78" pathLength="100" stroke-dasharray="75 100"/><circle class="mg-fill" cx="100" cy="100" r="78" pathLength="100" stroke-dasharray="' + (Math.min(real, 1) * 75).toFixed(2) + ' 100"/></svg><strong class="num">' + pc(real) + '</strong></div>' +
    '<dl class="mg-facts"><div><dt>Precisa por dia</dt><dd class="num">' + brl(need) + '</dd></div><div><dt>Fazendo por dia</dt><dd class="num ' + (pace >= need ? 'pos' : 'neg') + '">' + brl(pace) + ' <small>(' + pc(pace / need, 0) + ')</small></dd></div>' +
    '<div><dt>Projeção do mês</dt><dd class="num">' + brl(forecast) + '</dd></div><div><dt>Vendas por dia</dt><dd class="num">' + int(O.vendas / PASSED) + '</dd></div></dl></article>' +
    '<article class="panel mg-card" aria-labelledby="mg-res"><header class="mg-head"><h2 id="mg-res">Outubro até 28/10</h2></header><dl class="mg-facts mg-facts-1">' +
    [['Faturamento bruto', O.bruto == null ? 'Não atualizado nesta fonte' : brl(O.bruto)], ['Faturamento líquido', brl(O.liquido)], ['Gastos com anúncios', brl(O.gastos)], ['Lucro', brl(O.lucro)], ['ROAS', O.roas.toLocaleString('pt-BR', { minimumFractionDigits: 2 }) + 'x'], ['Margem', O.margem.toLocaleString('pt-BR') + '%']].map(([l, v]) => '<div><dt>' + l + '</dt><dd class="num">' + v + '</dd></div>').join('') + '</dl></article>' +
    '<article class="panel mg-card" aria-labelledby="mg-goals"><header class="mg-head"><h2 id="mg-goals">Metas Base, Alvo e Disney</h2></header><p class="mg-pending">Valores a definir por Pedro Ivo Torres.</p><dl class="mg-facts mg-facts-1"><div><dt>Setembro, mês fechado</dt><dd class="num">' + brl(S.liquido) + '</dd></div><div><dt>Lucro de setembro</dt><dd class="num">' + brl(S.lucro) + '</dd></div><div><dt>Projeção de outubro</dt><dd class="num">' + brl(forecast) + '</dd></div></dl></article>';

  /* ritmo de outubro: acumulado até 21/10 (total do mês menos os 7 dias) e série diária real de 22/10 a 28/10 */
  function chart() {
    const W = 1100, H = 300, L = 112, Rr = 16, T = 16, B = 34;
    const max = Math.max(S.liquido, forecast) * 1.08;
    const x = (d) => L + ((d - 1) / (DAYS - 1)) * (W - L - Rr);
    const y = (v) => T + (1 - v / max) * (H - T - B);
    let acc = O.liquido - D.reduce((a, d) => a + d.liquido, 0);
    const pts = [[x(21), y(acc)]].concat(D.map((d, i) => { acc += d.liquido; return [x(22 + i), y(acc)]; }));
    const real = 'M' + pts.map((p) => p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join('L');
    const gap = 'M' + x(1).toFixed(1) + ' ' + y(0).toFixed(1) + 'L' + pts[0][0].toFixed(1) + ' ' + pts[0][1].toFixed(1);
    const proj = 'M' + pts[pts.length - 1][0].toFixed(1) + ' ' + pts[pts.length - 1][1].toFixed(1) + 'L' + x(DAYS).toFixed(1) + ' ' + y(forecast).toFixed(1);
    const yt = [0, max / 3, (2 * max) / 3, max].map((v) => '<line class="vg-grid" x1="' + L + '" x2="' + (W - Rr) + '" y1="' + y(v).toFixed(1) + '" y2="' + y(v).toFixed(1) + '"/><text class="geo-axis" x="' + (L - 8) + '" y="' + (y(v) + 4).toFixed(1) + '" text-anchor="end">BRL ' + Math.round(v / 1000).toLocaleString('pt-BR') + ' mil</text>').join('');
    const xt = [1, 8, 15, 22, 28, 31].map((d) => '<text class="geo-axis" x="' + x(d).toFixed(1) + '" y="' + (H - 10) + '" text-anchor="middle">' + String(d).padStart(2, '0') + '/10</text>').join('');
    return '<svg class="vg-chart" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Faturamento líquido acumulado de outubro: ' + brl(O.liquido) + ' até 28/10. Projeção de ' + brl(forecast) + ' em 31/10. Setembro fechou com ' + brl(S.liquido) + '.">' + yt + xt +
      '<line class="mg-line mg-l-disney" x1="' + L + '" x2="' + (W - Rr) + '" y1="' + y(S.liquido).toFixed(1) + '" y2="' + y(S.liquido).toFixed(1) + '"/>' +
      '<path class="mg-gap" d="' + gap + '"/><path class="mg-real" d="' + real + '"/><path class="mg-proj" d="' + proj + '"/><circle class="mt-dot" cx="' + pts[pts.length - 1][0].toFixed(1) + '" cy="' + pts[pts.length - 1][1].toFixed(1) + '" r="5"/></svg>';
  }
  byId('mg-chart').innerHTML = chart();
  byId('mg-legend').innerHTML = '<li><i class="vg-k mg-k-real"></i>Realizado</li><li><i class="vg-k mg-k-base"></i>Projeção</li><li><i class="vg-k mg-k-disney"></i>Setembro</li>';

  const fu = (p) => { const f = p.produtos.find((x) => x.produto === 'Desafio Hiit Dance'), u = p.produtos.find((x) => x.produto === 'ACESSO VIP: Desafio Hiit Dance'); return [f.vendas, u.vendas]; };
  const [fs, us] = fu(S), [fo, uo] = fu(O);
  byId('mg-monthly').innerHTML = [['front', 'Vendas do front', fs, fo], ['upsell', 'Vendas de upsell', us, uo]].map(([k, l, s, o]) =>
    '<section class="panel mg-monthly" aria-labelledby="mg-m-' + k + '"><header class="mg-m-head"><h2 id="mg-m-' + k + '">' + l + '</h2>' + (k === 'upsell' ? '<span>' + pc(uo / fo, 2) + ' sobre o front em outubro</span>' : '') + '</header><ol class="mg-months">' +
    '<li><span class="mg-m-label">SET</span><b class="num">' + int(s) + '</b></li><li><span class="mg-m-label">OUT</span><b class="num">' + int(o) + '</b><span class="muted"> até 28/10</span></li><li><span class="mg-m-label">OUT, projeção</span><b class="num">' + int((o / PASSED) * DAYS) + '</b></li></ol></section>').join('');
})();
