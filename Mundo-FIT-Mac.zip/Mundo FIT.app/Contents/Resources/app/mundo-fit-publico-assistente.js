/* Abas Público (comportamento de compra e contas Meta) e Assistente (Agente ADK mundo_fit_operacao) com dados reais. */
(() => {
  const byId = (id) => document.getElementById(id);
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
  const int = (v) => Math.round(v).toLocaleString('pt-BR');
  const brl = (v) => (v < 0 ? 'BRL -' : 'BRL ') + Math.abs(v).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const pct = (v, d = 1) => v.toLocaleString('pt-BR', { minimumFractionDigits: d, maximumFractionDigits: d }) + '%';
  const x2 = (v) => (v == null ? 'Sem dado' : v.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + 'x');

  const R = window.MUNDOFIT_REAL;
  const O = R.periodos.outubro;
  const S = R.periodos.setembro;
  const P7 = (R.periodos_anteriores || R.periodos).sete_dias;

  /* 1. ABA PÚBLICO: Comportamento real de compra (Utmify) + Contas Meta */
  const pubRoot = byId('view-publico');
  if (pubRoot) {
    const fO = O.funil, fS = S.funil, f7 = P7.funil;
    const convO = (fO.vendas_aprovadas / fO.cliques) * 100;
    const convS = (fS.vendas_aprovadas / fS.cliques) * 100;
    const conv7 = (f7.vendas_aprovadas / f7.cliques) * 100;
    const icToSaleO = (fO.vendas_aprovadas / fO.ics) * 100;

    const purchase = document.createElement('section');
    purchase.setAttribute('aria-label', 'Conversão e produtos por período');
    purchase.innerHTML =
      '<p class="muted">Detalhamento de produtos, funil e origens: extração de 28/10 às 19:05. Estes quadros têm data própria e não seguem o filtro financeiro acima.</p><section class="cr-kpis" aria-label="Comportamento de compra em outubro">' +
      '<div class="panel cr-kpi"><span class="cr-kpi-label">Conversão clique → venda (Out)</span><strong class="num">' + pct(convO, 2) + '</strong><small>' + int(fO.vendas_aprovadas) + ' vendas sobre ' + int(fO.cliques) + ' cliques · Setembro: ' + pct(convS, 2) + '</small></div>' +
      '<div class="panel cr-kpi"><span class="cr-kpi-label">Checkout → venda aprovada (Out)</span><strong class="num">' + pct(icToSaleO, 1) + '</strong><small>' + int(fO.vendas_aprovadas) + ' aprovadas de ' + int(fO.ics) + ' checkouts iniciados</small></div>' +
      '<div class="panel cr-kpi"><span class="cr-kpi-label">Aprovação Pix vs Cartão (Out)</span><strong class="num">' + pct(O.aprovacao.pix, 1) + ' / ' + pct(O.aprovacao.cartao, 1) + '</strong><small>7 dias: Pix ' + pct(P7.aprovacao.pix, 1) + ' e Cartão ' + pct(P7.aprovacao.cartao, 1) + '</small></div>' +
      '<div class="panel cr-kpi"><span class="cr-kpi-label">Reembolso e chargeback (Out)</span><strong class="num">' + pct(O.reembolso_pct ?? 0, 2) + ' · ' + pct(O.chargeback_pct ?? 0, 2) + '</strong><small>7 dias (' + pct(conv7, 2) + ' conv.): reembolso ' + pct(P7.reembolso_pct ?? 0, 2) + '</small></div>' +
      '</section>' +
      '<div class="section-heading"><h2>Produtos comprados por período</h2></div>' +
      '<div class="table-panel panel"><div class="table-scroll" role="region" aria-label="Produtos comprados" tabindex="0"><table class="cr-table"><thead><tr><th>Produto</th><th class="right">Setembro</th><th class="right">Share Set</th><th class="right">Outubro (até 28/10)</th><th class="right">Share Out</th><th class="right">Últimos 7 dias</th></tr></thead><tbody>' +
      O.produtos.map((p) => {
        const ps = S.produtos.find((x) => x.produto === p.produto) || { vendas: 0, share_pct: 0 };
        const p7 = P7.produtos.find((x) => x.produto === p.produto) || { vendas: 0, share_pct: 0 };
        return '<tr><th scope="row">' + esc(p.produto) + '</th><td class="right num">' + int(ps.vendas) + '</td><td class="right num">' + pct(ps.share_pct, 1) + '</td><td class="right num"><b>' + int(p.vendas) + '</b></td><td class="right num">' + pct(p.share_pct, 1) + '</td><td class="right num">' + int(p7.vendas) + '</td></tr>';
      }).join('') +
      '</tbody></table></div></div>' +
      '';
    byId('view-visao').append(purchase);
    pubRoot.innerHTML = '<section class="panel vg-card"><h2>Perfil dos compradores</h2><p>Os dados do quiz Inlead ainda não foram conectados. Perfil de leads e perfil de compradores devem ser separados por vínculo com a compra. Idade, objetivo e outras respostas ainda não estão disponíveis.</p></section>' +
      '<div class="section-heading"><h2>Contas Meta Ads: recorte de 7 dias, extração às 19:05</h2></div>' +
      '<div class="table-panel panel"><div class="table-scroll" role="region" aria-label="Contas Meta Ads" tabindex="0"><table class="cr-table"><thead><tr><th>Conta de anúncio</th><th>Status</th><th class="right">Gasto histórico</th><th class="right">Vendas na semana</th><th class="right">Gastos (7d)</th><th class="right">Fat. atribuído (7d)</th><th class="right">Lucro atribuído (7d)</th><th class="right">ROAS (7d)</th></tr></thead><tbody>' +
      R.contas_meta.map((c) => '<tr><th scope="row">' + esc(c.conta) + ' <small class="muted">(' + esc(c.id_conta) + ')</small></th><td>' + esc(c.status) + '</td><td class="right num">' + brl(c.gasto_historico) + '</td><td class="right num">' + int(c.vendas_7d) + '</td><td class="right num">' + brl(c.gastos_7d) + '</td><td class="right num">' + brl(c.faturamento_7d) + '</td><td class="right num ' + (c.lucro_7d < 0 ? 'neg' : 'pos') + '">' + brl(c.lucro_7d) + '</td><td class="right num">' + x2(c.roas_7d) + '</td></tr>').join('') +
      '</tbody></table></div></div>' +
      '<section class="panel mf-empty"><p><b>Nota sobre perfil demográfico:</b> A Utmify registra o comportamento real de compra, pagamento e origem de tráfego acima. Os dados de idade, objetivo, dores e desejos dependem da conexão futura com o quiz do InLead e o aplicativo.</p></section>';
  }

  /* 2. ABA ASSISTENTE: Agente ADK mundo_fit_operacao */
  const asRoot = byId('view-assistente');
  if (asRoot) {
    const validWeek = R.semanas.at(-1);
    const validAds = validWeek.validados;
    const salesContas = R.contas_meta.reduce((a, c) => a + c.vendas_7d, 0);
    const fatContas = R.contas_meta.reduce((a, c) => a + c.faturamento_7d, 0);
    const lucroContas = R.contas_meta.reduce((a, c) => a + c.lucro_7d, 0);
    const naShare = (P7.fontes.find((f) => f.fonte === 'N/A') || { vendas: 569, share_pct: 13.3 });

    const TOOLS = {
      resumo: {
        fn: 'consultar_resumo_periodo("outubro")',
        title: 'Resumo consolidado (Setembro, Outubro e 7 dias)',
        run: () =>
          '<div class="cr-kpis">' +
          [['Setembro fechado', int(S.vendas) + ' vendas', 'Líquido ' + brl(S.liquido) + ' · Gastos ' + brl(S.gastos) + ' · Lucro ' + brl(S.lucro) + ' · ROAS ' + x2(S.roas)],
           ['Outubro até 28/10', int(O.vendas) + ' vendas', 'Líquido ' + brl(O.liquido) + ' · Gastos ' + brl(O.gastos) + ' · Lucro ' + brl(O.lucro) + ' · ROAS ' + x2(O.roas)],
           ['Últimos 7 dias', int(R.periodos.sete_dias.vendas) + ' vendas', 'Líquido ' + brl(R.periodos.sete_dias.liquido) + ' · Gastos ' + brl(R.periodos.sete_dias.gastos) + ' · Lucro ' + brl(R.periodos.sete_dias.lucro)],
           ['Hoje (28/10, parcial)', int(R.periodos.hoje.vendas) + ' vendas', 'Líquido ' + brl(R.periodos.hoje.liquido) + ' · Gastos ' + brl(R.periodos.hoje.gastos) + ' · Lucro ' + brl(R.periodos.hoje.lucro)]
          ].map(([l, v, s]) => '<div class="panel cr-kpi"><span class="cr-kpi-label">' + l + '</span><strong class="num">' + v + '</strong><small>' + s + '</small></div>').join('') +
          '</div>'
      },
      atribuicao: {
        fn: 'auditar_lacuna_atribuicao()',
        title: 'Auditoria da extração de 19:05, Resumo e Contas Meta (7 dias)',
        run: () =>
          '<div class="cr-kpis">' +
          '<div class="panel cr-kpi"><span class="cr-kpi-label">Lucro real do painel (7d)</span><strong class="num pos">' + brl(P7.lucro) + '</strong><small>' + int(P7.vendas) + ' vendas · ' + brl(P7.liquido) + ' líquidos · gastos ' + brl(P7.gastos) + '</small></div>' +
          '<div class="panel cr-kpi"><span class="cr-kpi-label">Soma atribuída às 9 contas Meta</span><strong class="num neg">' + brl(lucroContas) + '</strong><small>' + int(salesContas) + ' vendas atribuídas · ' + brl(fatContas) + ' atribuídos</small></div>' +
          '<div class="panel cr-kpi"><span class="cr-kpi-label">Receita fora das contas (7d)</span><strong class="num">' + brl(P7.liquido - fatContas) + '</strong><small>' + int(P7.vendas - salesContas) + ' vendas aprovadas não vinculadas às 9 contas</small></div>' +
          '<div class="panel cr-kpi"><span class="cr-kpi-label">Vendas sem UTM (N/A)</span><strong class="num">' + int(naShare.vendas) + ' (' + pct(naShare.share_pct, 1) + ')</strong><small>Outras origens são mostradas na Visão geral</small></div>' +
          '</div>'
      },
      criativos: {
        fn: 'status da planilha semanal',
        title: 'Validados na planilha: ' + validWeek.rotulo + ' (' + validAds.length + ' de ' + validWeek.subidos.length + ' linhas)' ,
        run: () =>
          '<div class="table-panel panel"><div class="table-scroll"><table class="cr-table"><thead><tr><th>Criativo</th><th>Card ClickUp</th><th>Copywriter</th><th>Editor</th><th class="right">Vendas na semana</th><th class="right">Gastos</th><th class="right">Faturamento</th><th class="right">Lucro</th><th class="right">ROAS</th></tr></thead><tbody>' +
          [...validAds].sort((a, b) => b.lucro - a.lucro).map((c) => '<tr><th scope="row">' + esc(c.nome) + '</th><td>' + esc(c.card || 'Família AD ' + c.familia) + '</td><td>' + esc(c.copy || '?') + '</td><td>' + esc(c.editor || '?') + '</td><td class="right num">' + int(c.vendas) + '</td><td class="right num">' + brl(c.gastos) + '</td><td class="right num">' + brl(c.faturamento) + '</td><td class="right num pos">' + brl(c.lucro) + '</td><td class="right num">' + x2(c.roas) + '</td></tr>').join('') +
          '</tbody></table></div></div>'
      },
      producao: {
        fn: 'consultar_producao_clickup(editor="todos")',
        title: 'Fila real da lista 6. PRODUÇÃO DE ADS (' + int(R.producao.total_cards) + ' cards no ClickUp)',
        run: () =>
          '<div class="table-panel panel"><div class="table-scroll"><table class="cr-table"><thead><tr><th>Card ClickUp</th><th>ID</th><th>Etapa atual</th><th>Editores no card</th><th class="right">Criado em</th><th class="right">Atualizado em</th><th class="right">Dias aberto</th></tr></thead><tbody>' +
          R.producao.gargalos.slice(0, 12).map((g) => '<tr><th scope="row">' + esc(g.nome) + '</th><td class="num">' + esc(g.id) + '</td><td><b>' + esc(g.status) + '</b></td><td>' + esc(g.editores.join(', ') || 'Sem editor') + '</td><td class="right num">' + g.criado_em + '</td><td class="right num">' + g.atualizado_em + '</td><td class="right num ' + (g.dias_aberto >= 15 ? 'neg' : '') + '">' + g.dias_aberto + ' d</td></tr>').join('') +
          '</tbody></table></div></div>'
      }
    };

    asRoot.innerHTML =
      '<section class="panel vg-filters" aria-label="Agente ADK Mundo FIT">' +
      '<div class="vg-filter-row"><div><b>Assistente de conferência:</b> consultas e cálculos dos dados disponíveis · <span id="adk-pg-status" class="muted">Verificando PostgreSQL 16...</span></div>' +
      '<div class="vg-periods" role="group" aria-label="Ferramentas ADK">' +
      '<button type="button" class="vg-period adk-btn" data-tool="atribuicao" aria-pressed="true">Auditar atribuição</button>' +
      '<button type="button" class="vg-period adk-btn" data-tool="criativos" aria-pressed="false">Criativos validados</button>' +
      '<button type="button" class="vg-period adk-btn" data-tool="producao" aria-pressed="false">Fila ClickUp</button>' +
      '<button type="button" class="vg-period adk-btn" data-tool="resumo" aria-pressed="false">Resumo períodos</button>' +
      '</div></div></section>' +
      '<div class="section-heading"><h2 id="adk-out-title"></h2></div>' +
      '<div id="adk-out"></div>';

    let liveAdk = null;
    const showTool = (key) => {
      const t = TOOLS[key] || TOOLS.atribuicao;
      document.querySelectorAll('.adk-btn').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.tool === key)));
      const srcBadge = liveAdk ? ' · API de conferência disponível' : ' · cálculo sobre os dados carregados';
      byId('adk-out-title').innerHTML = esc(t.title) + ' <small class="muted">· ' + esc(t.fn) + srcBadge + '</small>';
      byId('adk-out').innerHTML = t.run(liveAdk);
    };
    document.querySelectorAll('.adk-btn').forEach((b) => b.addEventListener('click', () => showTool(b.dataset.tool)));
    showTool('atribuicao');

    Promise.all([
      fetch('/api/postgres/resumo').then((r) => (r.ok ? r.json() : null)).catch(() => null),
      fetch('/api/adk/auditoria').then((r) => (r.ok ? r.json() : null)).catch(() => null)
    ]).then(([pg, adk]) => {
      const el = byId('adk-pg-status');
      if (adk && adk.status === 'ok') {
        liveAdk = adk;
      }
      if (el && pg && pg.status === 'ok') {
        el.textContent = 'PostgreSQL 16 ativo (' + pg.clickup_cards_total + ' cards ClickUp · ' + (pg.semanas_planilhas || []).length + ' planilhas semanais · consulta de dados disponível)';
      } else if (el && liveAdk) {
        el.textContent = 'API de conferência disponível';
      } else if (el) {
        el.textContent = 'Modo local estático';
      }
      const activeBtn = document.querySelector('.adk-btn[aria-pressed="true"]');
      showTool(activeBtn ? activeBtn.dataset.tool : 'atribuicao');
    });
  }
})();
